import { query as xgq } from "./api/anilist.js";
import { fetchAnimeGenres as fetchDedicatedAnimeGenres } from "./api/genders.js";
import { fetchAnimeGenres as fetchShikimoriGenreList } from "./api/shikimori.js";
import { fetchRandomAnime, fetchCatalogPage, fetchAnimeByIds, fetchAnimeById, fetchAnimePostersByIds, fetchAnimeRelated, fetchAnimeSimilar } from "./api/shikimori.js";
import { renderAnimeCard } from "./components/anime-card.js";
import { loadLocalState, initializeLocalState, saveLocalState } from "./core/storage.js";
import { initializeSupabaseAuth, signInWithEmail, signUpWithEmail, signOut, restoreCloudState, scheduleCloudSync, saveEpisodeProgress, saveEpisodeProgressBatch, uploadProfileAvatar, uploadProfileBanner, saveProfileDetails, saveProfilePrivacy, fetchPublicProfile, loadRecommendationFeedback, saveRecommendationFeedback, loadCalendarFollows, saveCalendarFollow } from "./core/supabase.js";
import { buildTasteProfile, rankRecommendations, normalizeRecommendationGenre } from "./core/recommendations.js";
import { activePage as getActivePage, updateNavigation, renderRoute, pageUrl, titleUrl, watchUrl as routeWatchUrl, routeArgs, isRoute, legacyRedirect } from "./core/router.js";
import { renderSiteHeader } from "./components/site-header.js";
import { renderFavorites, renderMyList, renderProfile, renderPublicProfile } from "./pages/collection.js";
import { renderCatalogPage } from "./pages/catalog.js";
import { renderHomePage } from "./pages/home.js";
import { renderAnimePage } from "./pages/anime.js";
import { renderWatchPage } from "./pages/watch.js";
import { renderRandomLoading, renderRandomError } from "./pages/discovery.js";
import { listen } from "./core/events.js";
import { renderTogetherPage } from "./pages/together.js";
import { listCollections, getCollection, createCollection, updateCollection, deleteCollection, addCollectionAnime, removeCollectionAnime, rateCollection } from "./core/collections.js";
import { renderCollectionsPage } from "./pages/collections.js";
import { createRoomCode, connectRoom, sendRoomEvent, disconnectRoom } from "./core/rooms.js";
import { searchProfiles, loadSocialHub, sendFriendRequest, respondFriendRequest, removeFriend, sendWatchInvite, respondWatchInvite, subscribeSocialUpdates } from "./core/friends.js";
import { fetchLibrary, mergeImportedLibrary } from "./core/library-import.js";
import { mountStreamPlayer } from "./core/streaming-player.js";
import { fetchAniLibriaHomeCollections } from "./api/anilibria.js";
import { searchKodikAnime } from "./api/kodik.js";
import { fetchShikimoriCalendar } from "./api/shikimori.js";
import { renderCalendarPage } from "./pages/calendar.js";
import { getCalendarPushState, enableCalendarPush, disableCalendarPush } from "./core/calendar-push.js";
import { createBannerManager } from "./components/banner.js";
(function(){
if(legacyRedirect())return;
renderSiteHeader();
var collectionSearchTimer=null,collectionSearchRequest=0,myListCloudAt=0,myListCloudPromise=null,myListRenderRequest=0;
var DUR=1420,GN=["Фэнтези","Экшен","Приключения","Романтика","Sci-Fi","Комедия","Детектив","Драма"];
// Тайтлы: [название, жанры, год, рейтинг, серий, статус, описание, цвет1, цвет2]
var D=[
["Тени Этерии","Фэнтези,Экшен",2026,8.9,12,"Онгоинг","Юный маг теряет память и попадает в мир, где магия — валюта.","#7c3aed","#db2777"],
["Хроники безмолвного моря","Приключения,Драма",2025,8.4,24,"Завершён","Команда исследователей ищет город, ушедший под воду.","#0891b2","#1e3a8a"],
["Последний маг","Экшен,Фэнтези",2026,8.7,12,"Онгоинг","Последний хранитель древней магии против империи.","#dc2626","#7c2d12"],
["Весна в Сакурагаве","Романтика,Драма",2024,8.1,13,"Завершён","Тихий городок, старая школа и одно неотправленное письмо.","#f472b6","#fb923c"],
["Кибер-ронин","Sci-Fi,Экшен",2026,8.6,12,"Онгоинг","Бывший самурай-киборг ищет создателя в неоновом мегаполисе.","#06b6d4","#6d28d9"],
["Школа звёздных ключей","Комедия,Sci-Fi",2025,7.8,12,"Завершён","Обычная школа оказывается порталом между галактиками.","#eab308","#ea580c"],
["Тихий детектив","Детектив,Драма",2023,8.8,24,"Завершён","Молчаливый сыщик раскрывает дела, которых не существует.","#475569","#0f172a"],
["Император пустоты","Фэнтези,Приключения",2025,9.0,25,"Завершён","Мальчик из трущоб наследует трон разрушенного мира.","#059669","#064e3b"],
["Девочка и дракон","Приключения,Комедия",2024,7.9,12,"Завершён","Дракон-пенсионер и юная путешественница меняют карту.","#f97316","#be123c"],
["Нулевой отряд","Экшен,Sci-Fi",2023,8.2,24,"Завершён","Отряд смертников защищает последнюю станцию.","#64748b","#7f1d1d"],
["Лунная кофейня","Романтика,Комедия",2026,8.0,12,"Онгоинг","Кофейня открывается только в полнолуние.","#a78bfa","#312e81"],
["Осколки миров","Фэнтези,Sci-Fi",2025,8.5,13,"Завершён","Разбитое зеркало открывает двери в соседние реальности.","#2dd4bf","#4c1d95"]
].map((a,i)=>({id:i,n:a[0],g:a[1].split(","),y:a[2],r:a[3],e:a[4],s:a[5],d:a[6],c:[a[7],a[8]]}));
var M={},H=[],AUTH_USER=null,AUTH_BUSY=false,socialChannelCleanup=null,socialLoadRequest=0,socialRefreshPending=false;
var $=s=>document.querySelector(s),app=$("#app"),S=loadLocalState(),F={g:"",s:"r",q:"",status:""},T=[],P=null,AP=false,V={};
function sv(){saveLocalState(S,M);scheduleCloudSync(S);if(activePage()==="home")refreshContinueShelf()}
function recordWatchEntry(anime,episode){if(!anime||!Number(anime.id)||!Number(episode))return;S.hist=S.hist||{};var previous=S.hist[anime.id],same=previous&&Number(previous.ep)===Number(episode);S.hist[anime.id]={ep:Number(episode),t:same?Math.max(0,Number(previous.t)||0):0,duration:same?Math.max(0,Number(previous.duration)||0):0,at:Date.now(),speed:same&&Number(previous.speed)>0?Number(previous.speed):1};sv()}
function df(){S.autoNextEpisode=S.autoNextEpisode!==false;S.fav=S.fav||[];S.hist=S.hist||{};S.watchedEpisodes=S.watchedEpisodes||{};S.rate=S.rate||{};S.watchlist=S.watchlist||{};S.name=S.name||"Гость";S.acc=S.acc||"#8b5cf6"}
df();
function watchUrl(id,episode){var url=routeWatchUrl(id,episode);if(S&&S.room)url+=(url.indexOf("?")>=0?"&":"?")+"room="+encodeURIComponent(S.room);return url}
var LISTS=[["watching","Смотрю"],["planned","Запланировано"],["completed","Просмотрено"],["dropped","Брошено"]];
var esc=s=>String(s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
var un=s=>String(s||"").replace(/&quot;/g,'"').replace(/&gt;/g,">").replace(/&lt;/g,"<").replace(/&amp;/g,"&");
var gr=d=>"linear-gradient(160deg,"+d.c[0]+","+d.c[1]+")";
function shikiImageUrl(path){
 if(!path)return "";
 var value=String(path).trim();if(!value)return "";
 var url=value.startsWith("//")?"https:"+value:value.startsWith("http")?value:"https://shikimori.io"+(value.startsWith("/")?value:"/"+value);
 try{var parsed=new URL(url);if(/\/missing_original(?:\.[a-z0-9]+)?$/i.test(parsed.pathname))return "";return url}catch(e){return ""}
}
var bg=d=>{var image=shikiImageUrl(d.img);return(image?"url('"+image+"') center/cover no-repeat,":"")+gr(d)};
var bn=d=>{var image=shikiImageUrl(d.ban);return "linear-gradient(0deg,#000 5%,rgba(0,0,0,.12) 65%,rgba(0,0,0,.08)), "+(image?"url('"+image+"') center/cover no-repeat,":"")+gr(d)};
var fm=t=>{t=Math.floor(t);return(t/60|0)+":"+("0"+t%60).slice(-2)};
var srt=k=>D.slice().sort((a,b)=>k=="n"?a.n.localeCompare(b.n):b[k]-a[k]);
function card(d,pr,href,badge){return renderAnimeCard(d,{state:S,background:bg,progress:pr,href:href||titleUrl(d.id),badge:badge})}
var row=(t,a,sub,id)=>'<section class="shelf"'+(id?' id="'+id+'"':"")+'><div class="shelf-head"><div><h2>'+t+'</h2>'+(sub?'<p class="shelf-sub">'+sub+'</p>':"")+'</div></div><div class="row">'+a.join("")+'</div></section>';
var epLabel=d=>d.e>0?d.e+" серий":d.ae>0?"Вышло "+d.ae+" серий":"Количество серий уточняется";
var epTotal=d=>Math.max(Number(d&&d.e)||0,Number(d&&d.kodikEpisodeCount)||0,Number(d&&d.ae)||0);
var availableEpCount=d=>{if(Number(d&&d.kodikAvailableEpisodes)>0)return Number(d.kodikAvailableEpisodes);var id=Number(d&&d.id),mal=Number(d&&d.mal),records=[S.aniEpisodes&&S.aniEpisodes[id],S.aniZipEpisodes&&S.aniZipEpisodes[id],S.kitsuEpisodes&&S.kitsuEpisodes[mal]].filter(x=>x&&Number.isFinite(Number(x.available))),counts=records.map(x=>Math.max(0,Number(x.available)));if(Number(d&&d.ae)>0)counts.push(Number(d.ae));if(counts.length)return Math.max(...counts);return ["Завершён","FINISHED"].includes(d&&d.s)?epTotal(d):null};
var watchedFor=id=>Array.isArray(S.watchedEpisodes&&S.watchedEpisodes[id])?S.watchedEpisodes[id].map(Number):[];
var eps=(d,cur,inline=false)=>{var total=epTotal(d);if(!total)return '<p class="m">Количество серий пока неизвестно.</p>';var watched=watchedFor(d.id),available=availableEpCount(d);return Array.from({length:total},(_,k)=>{var n=k+1,done=watched.includes(n),upcoming=available!==null&&n>available;return '<span class="episode-item'+(done?' is-watched':'')+(upcoming?' is-upcoming':'')+'">'+(upcoming?'<span class="episode-number" aria-label="Серия '+n+' ещё не вышла">'+n+'</span><small class="episode-upcoming-label">Скоро</small>':'<a href="'+watchUrl(d.id,n)+'" class="'+(n==cur?'on':'')+'" aria-label="Открыть отдельную страницу просмотра, серия '+n+'">'+n+'</a>')+(inline?'<button type="button" class="episode-inline-play" data-a="inline-watch" data-i="'+d.id+'" data-v="'+n+'" aria-label="'+(upcoming?'Серия ещё не вышла':'Смотреть серию '+n+' здесь')+'" '+(upcoming?'disabled title="Серия ещё не вышла"':'')+'>▶</button>':'')+'<button type="button" class="episode-watch-toggle'+(done?' is-watched':'')+'" data-a="episode-toggle" data-i="'+d.id+'" data-v="'+n+'" aria-label="'+(upcoming?'Серия ещё не вышла':done?'Убрать отметку о просмотре серии ':'Отметить серию как просмотренную ')+n+'" aria-pressed="'+done+'" '+(upcoming?'disabled title="Серия ещё не вышла"':'')+'>'+(upcoming?'–':done?'✓':'○')+'</button></span>'}).join('')};
function refreshEpisodeMarks(id){var watched=watchedFor(id),total=epTotal(M[id]||{}),count=watched.length;document.querySelectorAll('.episode-item').forEach(item=>{var b=item.querySelector('[data-a="episode-toggle"]');if(!b||Number(b.dataset.i)!==Number(id))return;var n=Number(b.dataset.v),done=watched.includes(n);item.classList.toggle('is-watched',done);b.classList.toggle('is-watched',done);b.setAttribute('aria-pressed',String(done));b.setAttribute('aria-label',(done?'Убрать отметку о просмотре серии ':'Отметить серию как просмотренную ')+n);b.textContent=done?'✓':'○'});document.querySelectorAll('[data-episode-progress="'+id+'"]').forEach(el=>{el.textContent=count+' / '+(total||'—')+' просмотрено'})}
function setEpisodeWatched(id,episode,done){var anime=M[Number(id)],available=anime?availableEpCount(anime):null;if(available!==null&&Number(episode)>available){toast("Эта серия ещё не вышла");return}S.watchedEpisodes=S.watchedEpisodes||{};S.episodeProgressPending=S.episodeProgressPending||{};var number=Number(episode),owner=AUTH_USER?AUTH_USER.id:"guest",key=owner+"|"+Number(id)+":"+number,list=watchedFor(id).filter(n=>n!==number);if(done)list.push(number);list.sort((a,b)=>a-b);if(list.length)S.watchedEpisodes[id]=list;else delete S.watchedEpisodes[id];S.episodeProgressPending[key]=!!done;sv();refreshEpisodeMarks(id);if(AUTH_USER){var userId=AUTH_USER.id;saveEpisodeProgress(id,number,!!done,userId).then(saved=>{if(saved===true&&S.episodeProgressPending&&S.episodeProgressPending[key]===!!done){delete S.episodeProgressPending[key];saveLocalState(S,M)}}).catch(error=>console.warn("[AniWatch] Episode progress save failed; change kept locally:",error))}}
window.addEventListener("aw-episode-progress-changed",event=>{
 var detail=event.detail||{};if(!AUTH_USER||detail.userId!==AUTH_USER.id)return;
 var previous=S.watchedEpisodes||{},next={};
 if(Array.isArray(detail.rows)){
  detail.rows.forEach(row=>{var id=String(Number(row.anime_id)),episode=Number(row.episode);if(row.is_watched&&Number.isSafeInteger(Number(id))&&Number(id)>0&&Number.isInteger(episode)&&episode>0){next[id]=next[id]||[];next[id].push(episode)}});
 }else if(detail.row){
  Object.entries(previous).forEach(([id,list])=>{next[id]=Array.isArray(list)?list.slice():[]});
  var row=detail.row,id=String(Number(row.anime_id)),episode=Number(row.episode);
  if(Number.isSafeInteger(Number(id))&&Number(id)>0&&Number.isInteger(episode)&&episode>0){
   next[id]=(next[id]||[]).filter(n=>n!==episode);
   if(row.is_watched)next[id].push(episode);
   if(!next[id].length)delete next[id];
  }
 }
 Object.values(next).forEach(list=>{list.sort((a,b)=>a-b)});
 Object.entries(S.episodeProgressPending||{}).forEach(([key,value])=>{
  var match=/^(?:(guest|[0-9a-f-]+)\|)?(\d+):(\d+)$/i.exec(key);if(!match)return;
  var owner=match[1]||"guest";if(owner!=="guest"&&owner!==AUTH_USER.id)return;
  if(owner==="guest"&&S.episodeProgressOwner&&S.episodeProgressOwner!==AUTH_USER.id)return;
  var id=match[2],episode=Number(match[3]);next[id]=(next[id]||[]).filter(n=>n!==episode);
  if(value){next[id].push(episode);next[id].sort((a,b)=>a-b)}
  if(!next[id].length)delete next[id];
 });
 var changedIds=new Set([...Object.keys(previous),...Object.keys(next)]);
 S.watchedEpisodes=next;saveLocalState(S,M);changedIds.forEach(refreshEpisodeMarks);
 if(activePage()==="home")refreshContinueShelf();
});
function toast(m){var t=$("#toast");t.textContent=m;t.classList.add("on");clearTimeout(toast.h);toast.h=setTimeout(()=>t.classList.remove("on"),2000)}
// Dialogs keep keyboard focus inside themselves and return it to the opener.
var dialogReturnFocus=null;
function dialogFocusables(root){return Array.prototype.slice.call(root.querySelectorAll('a[href],button:not([disabled]),input:not([disabled]):not([type="hidden"]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])')).filter(function(el){return el.getClientRects().length>0})}
function openDialog(root,preferred){dialogReturnFocus=document.activeElement;var target=preferred||dialogFocusables(root)[0];if(target&&typeof target.focus==="function")target.focus()}
function closeDialog(root){if(root&&root.parentNode)root.remove();var back=dialogReturnFocus;dialogReturnFocus=null;if(back&&document.contains(back))back.focus()}
listen(document,"keydown",e=>{
 if(e.key!=="Tab")return;
 var dialog=document.querySelector('[role="dialog"][aria-modal="true"]');if(!dialog)return;
 var list=dialogFocusables(dialog);if(!list.length){e.preventDefault();return}
 var first=list[0],last=list[list.length-1];
 if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus()}
 else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus()}
 else if(!dialog.contains(document.activeElement)){e.preventDefault();first.focus()}
});
function exportBackup(){
 try{
  var payload={format:"AniWatchBackup",version:1,exportedAt:new Date().toISOString(),state:S};
  var blob=new Blob([JSON.stringify(payload,null,2)],{type:"application/json"});
  var url=URL.createObjectURL(blob),a=document.createElement("a");
  a.href=url;a.download="aniwatch-backup-"+new Date().toISOString().slice(0,10)+".json";
  document.body.appendChild(a);a.click();a.remove();URL.revokeObjectURL(url);
  toast("Резервная копия сохранена");
 }catch(e){console.error("[AniWatch] Backup export failed",e);toast("Не удалось экспортировать данные")}
}
async function importBackup(file){
 if(!file)return;
 try{
  var payload=JSON.parse(await file.text()),state=payload&&payload.state;
  if(!payload||payload.format!=="AniWatchBackup"||payload.version!==1||!state||typeof state!=="object"||Array.isArray(state))throw new Error("Неподдерживаемый формат резервной копии");
  if(!Array.isArray(state.fav)||!state.hist||typeof state.hist!=="object"||!state.rate||typeof state.rate!=="object")throw new Error("Файл не похож на резервную копию AniWatch");
  if(!confirm("Импорт заменит текущие локальные данные. Продолжить?"))return;
  S=state;df();sv();draw();toast("Резервная копия восстановлена");
 }catch(e){console.error("[AniWatch] Backup import failed",e);toast(e.message||"Не удалось импортировать файл")}
}
function cleanDesc(v){return String(v||"").replace(/<[^>]*>/g," ").replace(/\[\/?[a-z][a-z0-9_]*(?:=[^\]]*)?\]/gi,"").replace(/\[\[|\]\]/g,"").replace(/[\u3040-\u30ff\u3400-\u4dbf\u4e00-\u9fff々〆ヵヶ]+/g," ").replace(/\s+/g," ").trim()}
function shortDesc(v,n){var s=cleanDesc(v);if(s.length<=n)return s;var cut=s.slice(0,n);return cut.slice(0,cut.lastIndexOf(" "))+"…"}

var featuredIndex=0;
function featured(){
 var d=H[featuredIndex%H.length]||D[0];
 ru(d);
 var rd=shortDesc((S.ru&&S.ru[d.id]&&S.ru[d.id].d)||d.d,190);
 var rating=d.r?Number(d.r).toFixed(1):"—";
 var banner=shikiImageUrl(d.ban);
 return '<section class="hero hero-editorial aurora-hero" style="--hero-poster:'+(banner?"url(\'"+banner+"\')":"none")+';background:'+bn(d)+'">'+
  '<div class="hero-copy">'+
   '<div class="eyebrow"><span class="live-dot"></span> В центре внимания</div>'+
   '<small class="hero-meta">'+d.g.slice(0,3).map(esc).join(" · ")+' <i>•</i> '+esc(d.y)+' <i>•</i> '+esc(d.s||"Аниме")+'</small>'+
   '<h1>'+esc(d.n)+'</h1>'+
   '<p id="featured-desc" data-id="'+d.id+'">'+esc(rd)+'</p>'+
   '<div class="hero-facts">'+
    '<span class="hero-rating"><svg viewBox="0 0 20 20" aria-hidden="true"><path d="m10 1.8 2.45 5 5.52.8-3.99 3.89.94 5.5L10 14.4l-4.92 2.59.94-5.5L2.03 7.6l5.52-.8L10 1.8Z" fill="currentColor"/></svg><b>'+rating+'</b></span>'+
    '<span class="hero-episodes" id="featured-count" data-id="'+d.id+'">'+esc(epLabel(d))+'</span>'+
   '</div>'+
   '<div class="acts">'+
    '<a class="btn hero-watch" href="'+watchUrl(d.id,1)+'"><svg viewBox="0 0 20 20" aria-hidden="true"><path d="M6 3.8c0-.8.9-1.3 1.6-.9l9 5.2a1 1 0 0 1 0 1.8l-9 5.2c-.7.4-1.6-.1-1.6-.9V3.8Z" fill="currentColor"/></svg><span>Смотреть</span></a>'+
    '<a class="btn ghost hero-details" href="'+titleUrl(d.id)+'"><span>Подробнее</span><svg viewBox="0 0 20 20" aria-hidden="true"><path d="M4 10h11m-4-4 4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg></a>'+
   '</div>'+
  '</div>'+

  (H.length>1?'<button class="hero-arrow hero-prev" data-a="slide" data-v="-1" aria-label="Предыдущий баннер"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="m14.5 5-7 7 7 7" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg></button><button class="hero-arrow hero-next" data-a="slide" data-v="1" aria-label="Следующий баннер"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="m9.5 5 7 7-7 7" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg></button><div class="hero-dots">'+H.map((x,i)=>'<button data-a="slide-to" data-v="'+i+'" class="'+(i===featuredIndex%H.length?"on":"")+'" aria-label="Баннер '+(i+1)+'"></button>').join("")+'</div>':"")+
 '</section>';
}
function showFeatured(){var hw=$("#hw");if(hw)hw.innerHTML=featured()}
function animeProgress(d){
 var total=availableEpCount(d)||epTotal(d);
 if(!total)return 0;
 var watched=watchedFor(d.id).filter(n=>n>0&&n<=total).length;
 return Math.min(100,Math.round(watched/total*100));
}
function continueWatchingEntries(){return Object.keys(S.hist||{}).filter(k=>Number(k)>0&&M[k]&&S.hist[k]&&Number(S.hist[k].ep)>0).sort((a,b)=>Number(S.hist[b].at||0)-Number(S.hist[a].at||0)).slice(0,6)}
function continueWatchingCards(){return continueWatchingEntries().map(k=>{var h=S.hist[k],time=Math.max(0,Number(h.t)||0),duration=Math.max(0,Number(h.duration)||0),progress=duration>0?Math.min(100,Math.round(time/duration*100)):null;return card(M[k],progress,watchUrl(k,Number(h.ep)||1),"Серия "+Number(h.ep))})}
function refreshContinueShelf(){var host=$("#continue-shelf");if(!host)return;var cards=continueWatchingCards();host.outerHTML=row("Продолжить просмотр",cards.length?cards:['<p class="m">Начни смотреть аниме — здесь появится твой прогресс.</p>'],"Вернись к серии, на которой остановился","continue-shelf")}

var cloudRefreshPromise=null,cloudRefreshAt=0;
async function refreshCloudProgress(force=false){
 if(!AUTH_USER||cloudRefreshPromise||(!force&&Date.now()-cloudRefreshAt<20000))return cloudRefreshPromise;
 cloudRefreshAt=Date.now();
 cloudRefreshPromise=(async()=>{
  try{
   var merged=await restoreCloudState(S,AUTH_USER.id);
   if(!AUTH_USER)return;
   S=merged;
   saveLocalState(S,M);
   await xhyd();
   if(activePage()==="home")refreshContinueShelf();
  }catch(error){console.warn("[AniWatch] Cloud progress refresh failed:",error)}
  finally{cloudRefreshPromise=null}
 })();
 return cloudRefreshPromise;
}
window.addEventListener("focus",()=>refreshCloudProgress(true));
document.addEventListener("visibilitychange",()=>{if(!document.hidden)refreshCloudProgress(true)});
setInterval(()=>{if(!document.hidden)refreshCloudProgress(false)},30000);

V.home=()=>{
 if(!D.length&&!(homeCollections&&homeCollections.popular&&homeCollections.popular.length)){app.innerHTML='<section class="offline-state"><div class="eyebrow">КАТАЛОГ</div><h1>Не удалось загрузить каталог</h1><p>Проверь подключение к интернету и попробуй ещё раз. Мы не будем показывать выдуманные карточки вместо реальных данных.</p><button class="btn" type="button" data-a="reload">Повторить загрузку</button></section>';return}
 if(!D.length&&homeCollections&&homeCollections.popular.length)D=homeCollections.popular;
 featuredIndex=0;
 var cont=continueWatchingCards();
 var source=homeCollections||{popular:D,recommended:[],ongoing:D.filter(d=>/Онгоинг|RELEASING/i.test(d.s||"")),recent:[]};
 var popular=source.popular.map(d=>{M[d.id]=d;return card(d)});
 var recommended=source.recommended.map(d=>{M[d.id]=d;return card(d)});
 var ongoing=source.ongoing.map(d=>{M[d.id]=d;return card(d)});
 var recent=source.recent.map(d=>{M[d.id]=d;return card(d)});
 renderHomePage({app,featured:featured(),continueCards:cont,popularCards:popular,recommendedCards:recommended,ongoingCards:ongoing,recentCards:recent,row});
 bannerManager.loadFeatured(H).catch(error=>console.warn("[AniWatch] Featured banners could not be loaded:",error));
 loadHomeRecommendations();
 refreshContinueShelf();
 if(H.length>1)T.push(setInterval(()=>{featuredIndex=(featuredIndex+1)%H.length;showFeatured()},7000));

};


var recommendationRequest=0,recommendationLoading=false;
function recommendationLibrary(){
 var ids=new Set([].concat(Object.keys(S.rate||{}),Object.keys(S.watchlist||{}),Object.keys(S.hist||{}),Object.keys(S.watchedEpisodes||{}),S.fav||[]).map(Number));
 return [...ids].map(id=>{
  var anime=M[id]||(S.shikiAnime&&S.shikiAnime[id]);
  if(!anime)return null;
  var stars=Number(S.rate&&S.rate[id])||0;
  return {id:id,shikiId:Number(anime.shikiId)||(anime.source==="shikimori"&&id>=1000000000?id-1000000000:0),mal:Number(anime.mal)||0,title:un(anime.n||anime.russian||anime.name||"аниме"),genres:anime.g||[],rating:stars>0?stars*2:null,ratingStars:stars,favorite:(S.fav||[]).map(Number).includes(id),status:S.watchlist&&S.watchlist[id],watchedCount:Array.isArray(S.watchedEpisodes&&S.watchedEpisodes[id])?S.watchedEpisodes[id].length:0};
 }).filter(Boolean);
}
function recommendationExcludedIds(){
 var excluded=new Set([].concat(Object.keys(S.rate||{}),Object.keys(S.watchlist||{}),Object.keys(S.hist||{}),Object.keys(S.watchedEpisodes||{}),Object.keys(S.recommendationDismissed||{}),S.fav||[]).map(Number).filter(id=>Number.isFinite(id)&&id>0));
 recommendationLibrary().forEach(item=>{if(item.mal>0)excluded.add("mal:"+item.mal)});
 ["recent","ongoing","popular","recommended"].forEach(key=>(homeCollections&&homeCollections[key]||[]).forEach(item=>{if(Number(item.id)>0)excluded.add(Number(item.id));if(Number(item.mal)>0)excluded.add("mal:"+Number(item.mal));if(Number(item.shikiId)>0)excluded.add(1000000000+Number(item.shikiId))}));
 return excluded;
}
function recommendationSeeds(library){
 return library.filter(item=>item.shikiId>0&&(item.ratingStars>=4||item.favorite||item.watchedCount>0||item.status==="completed"||item.status==="watching"))
  .map(item=>({item:item,priority:(item.ratingStars>=4?item.ratingStars*2:0)+(item.favorite?3:0)+(item.status==="completed"?1.5:0)+(item.status==="watching"?1:0)+Math.min(2,item.watchedCount*0.15)}))
  .sort((a,b)=>b.priority-a.priority).slice(0,3).map(entry=>entry.item);
}
function renderRecommendationStarter(host,selected){
 if(!host)return;
 var choices=Array.isArray(selected)?selected:[];
 host.innerHTML='<div class="recommendation-starter"><p>Пока мало данных о твоём вкусе. Выбери до трёх любимых жанров — по ним начнём подборку.</p><div class="recommendation-starter-genres">'+GN.map(genre=>'<button type="button" class="btn ghost'+(choices.includes(genre)?' active':'')+'" data-a="recommendation-genre" data-v="'+esc(genre)+'" aria-pressed="'+choices.includes(genre)+'">'+esc(genre)+'</button>').join("")+'</div><button type="button" class="btn" data-a="recommendation-start" '+(choices.length?'':'disabled')+'>Подобрать аниме</button></div>';
}
function recommendationCacheKey(profile,seeds){
 return (profile.topGenres||[]).slice(0,3).map(item=>item.name).join(",")+"|"+seeds.map(item=>item.shikiId).join(",");
}
function readRecommendationPool(key){
 try{
  var cached=JSON.parse(localStorage.getItem("aw.recommendation.pool.v1")||"null");
  if(cached&&cached.key===key&&Date.now()-Number(cached.at)<6*60*60*1000&&Array.isArray(cached.items))return cached.items;
 }catch(error){}
 return null;
}
function writeRecommendationPool(key,items){
 try{
  var compact=items.slice(0,180).map(entry=>{
   var a=entry.anime||{};
   return {sourceType:entry.sourceType||"catalog",sourceTitle:entry.sourceTitle||"",anime:{id:Number(a.id),name:a.name||"",russian:a.russian||"",myanimelist_id:Number(a.myanimelist_id)||null,score:Number(a.score)||0,status:a.status||"",genres:Array.isArray(a.genres)?a.genres.map(g=>({name:g.name||"",russian:g.russian||""})):[],aired_on:a.aired_on||null,episodes:Number(a.episodes)||0,description:String(a.description||"").slice(0,500),kind:a.kind||""}};
  }).filter(entry=>entry.anime.id>0);
  localStorage.setItem("aw.recommendation.pool.v1",JSON.stringify({key:key,at:Date.now(),items:compact}));
 }catch(error){console.warn("[AniWatch] Recommendation pool cache unavailable:",error)}
}
async function loadHomeRecommendations(){
 var host=$("#recommendation-cards");
 if(!host||recommendationLoading)return;
 recommendationLoading=true;
 var request=++recommendationRequest;
 host.innerHTML='<p class="m">Подбираем аниме по твоей библиотеке…</p>';
 try{
  var library=recommendationLibrary(),profile=buildTasteProfile(library,S.recommendationGenres||[]),raw=[],seeds=recommendationSeeds(library);
  var shelf=host.closest(".shelf");
  if(shelf)shelf.hidden=false;
  if(profile.usefulSignals<1||profile.topGenres.length<1){renderRecommendationStarter(host,S.recommendationGenres||[]);if(shelf)shelf.hidden=false;return}
  var cacheKey=recommendationCacheKey(profile,seeds),cached=readRecommendationPool(cacheKey);
  if(cached)raw=cached;
  else{
   var seen=new Map();
   function addCandidate(value,sourceType,sourceTitle){
    var anime=value&&value.anime?value.anime:value;
    var id=Number(anime&&anime.id);if(!Number.isInteger(id)||id<=0)return;
    var previous=seen.get(id);
    if(previous){if(previous.sourceType!=="similar"&&sourceType==="similar")seen.set(id,{anime:anime,sourceType:sourceType,sourceTitle:sourceTitle||""});return}
    var entry={anime:anime,sourceType:sourceType||"catalog",sourceTitle:sourceTitle||""};seen.set(id,entry);raw.push(entry);
   }
   // Similarity calls are bounded to the three strongest positive library signals.
   for(var seed of seeds){
    try{
     var similar=await fetchAnimeSimilar(seed.shikiId);
     (similar||[]).forEach(item=>addCandidate(item,"similar",seed.title));
    }catch(error){console.warn("[AniWatch] Similar-title recommendation request failed:",error)}
   }
   // Explore the three strongest preferred genres rather than only the first one.
   try{
    var genreRows=await fetchShikimoriGenreList(),wanted=(profile.topGenres||[]).slice(0,3);
    var genreIds=wanted.map(preference=>{
     var match=genreRows.find(g=>g&&g.kind==="genre"&&String(g.entry_type||"").toLowerCase()==="anime"&&[g.russian,g.name].some(name=>normalizeRecommendationGenre(name)===normalizeRecommendationGenre(preference.name)));
     return match&&String(match.id||"");
    }).filter(Boolean);
    for(var genreId of genreIds){
     try{var genreItems=await fetchCatalogPage({page:1,limit:35,order:"popularity",genre:genreId});(genreItems||[]).forEach(item=>addCandidate(item,"genre",""))}
     catch(error){console.warn("[AniWatch] Recommendation genre request failed:",error)}
    }
   }catch(error){console.warn("[AniWatch] Recommendation genres unavailable:",error)}
   if(raw.length<30){
    try{var popularItems=await fetchCatalogPage({page:1,limit:50,order:"popularity"});(popularItems||[]).forEach(item=>addCandidate(item,"catalog",""))}
    catch(error){console.warn("[AniWatch] Recommendation popularity fallback failed:",error)}
   }
   if(raw.length<18){
    try{var rankedItems=await fetchCatalogPage({page:1,limit:50,order:"ranked"});(rankedItems||[]).forEach(item=>addCandidate(item,"catalog",""))}
    catch(error){console.warn("[AniWatch] Recommendation ranking fallback failed:",error)}
   }
   if(raw.length)writeRecommendationPool(cacheKey,raw);
  }
  if(request!==recommendationRequest||activePage()!=="home")return;
  var candidates=raw.map(entry=>{
   var anime=shikiToItem(entry.anime||entry);
   anime.recommendationSourceType=entry.sourceType||"catalog";
   anime.recommendationSourceTitle=entry.sourceTitle||"";
   return anime;
  }),excluded=recommendationExcludedIds();
  var ranked=rankRecommendations(candidates,profile,excluded,12);
  if(!ranked.length){if(shelf)shelf.hidden=true;return}
  ranked.forEach(item=>{M[item.anime.id]=item.anime;S.shikiAnime=S.shikiAnime||{};S.shikiAnime[item.anime.id]=item.anime});
  host.innerHTML=ranked.map(item=>'<div class="recommendation-item">'+card(item.anime)+'<p class="recommendation-reason">'+esc(item.reason)+'</p><button class="recommendation-dismiss" type="button" data-a="recommendation-dismiss" data-i="'+item.anime.id+'">Не интересно</button></div>').join("");
  xshikiPosters(ranked.map(item=>item.anime)).catch(error=>console.warn("[AniWatch] Recommendation poster lookup failed:",error));
  sv();
 }catch(error){
  console.warn("[AniWatch] Recommendations unavailable:",error);
  if(request===recommendationRequest&&activePage()==="home")host.innerHTML='<p class="m">Не удалось загрузить рекомендации. Попробуй обновить главную позже.</p>';
 }finally{recommendationLoading=false}
}
var rc;

function startInlineWatch(anime,episode){
 var available=availableEpCount(anime);if(available!==null&&Number(episode)>available){toast("Эта серия ещё не вышла");return}
 var host=$("#inline-stream-player"),section=$("#inline-watch-section");if(!host||!section)return;
 if(INLINE_STREAM_PLAYER){INLINE_STREAM_PLAYER.destroy();INLINE_STREAM_PLAYER=null}
 section.hidden=false;
 var title=$("#inline-watch-title");if(title)title.textContent=anime.n+" · серия "+episode;var full=$("#inline-open-full");if(full)full.href=watchUrl(anime.id,episode);
 document.querySelectorAll(".episode-inline-play").forEach(b=>{b.classList.toggle("on",Number(b.dataset.v)===Number(episode));b.textContent=Number(b.dataset.v)===Number(episode)?"Ⅱ":"▶"});
 var inlineHistory=S.hist[anime.id],inlineResume=inlineHistory&&Number(inlineHistory.ep)===Number(episode)?inlineHistory:{};
 recordWatchEntry(anime,episode);
 INLINE_STREAM_PLAYER=mountStreamPlayer({root:host,anime,episode,resumeAt:Number(inlineResume.t)||0,resumeSpeed:Number(inlineResume.speed)||1,onEpisodeEnded:()=>{
  setEpisodeWatched(anime.id,episode,true);
  var nextAvailable=availableEpCount(anime);
  var next=section.querySelector('.episode-inline-play[data-v="'+(episode+1)+'"]');
  if(nextAvailable!==null&&episode<nextAvailable){
   S.hist[anime.id]={ep:episode+1,t:0,at:Date.now()};sv();
   if(next){next.classList.add("next-ready");toast("Серия отмечена. Можно включить следующую.");}
  }else{
   delete S.hist[anime.id];sv();
   toast("Серия отмечена как просмотренная");
  }
 },onPlayback:media=>{
  var now=Date.now(),time=Math.max(0,Number(media.time)||0);
  if(time>0){S.hist[anime.id]={ep:episode,t:time,duration:Math.max(0,Number(media.duration)||0),at:now,speed:Number(media.speed)||1};if(!startInlineWatch.lastSave||now-startInlineWatch.lastSave>=5000||!media.playing){startInlineWatch.lastSave=now;sv()}}
 }});
 section.scrollIntoView({behavior:"smooth",block:"start"});
}
var nextAiringRequest=0;
async function loadNextEpisode(d){
 var host=$("#next-episode-info");
 if(!host||!d)return;
 var request=++nextAiringRequest,cacheKey="",shikiId=Number(d.shikiId)||((Number(d.id)>=1000000000)?Number(d.id)-1000000000:0);
 try{
  if(!shikiId&&Number(d.mal)>0){
   cacheKey="aw-shiki-id-mal-"+Number(d.mal);
   try{var saved=JSON.parse(localStorage.getItem(cacheKey)||"null");if(saved&&Number(saved.id)>0&&Date.now()-Number(saved.at)<30*864e5)shikiId=Number(saved.id)}catch(e){}
   if(!shikiId){
    var names=[un(d.n),un(d.o)].filter((value,index,list)=>value&&list.indexOf(value)===index);
    for(var name of names){
     var matches=await fetchCatalogPage({query:name,page:1,limit:30,order:"popularity"});
     var exact=matches.find(item=>Number(item.mal_id||item.myanimelist_id)===Number(d.mal));
     if(exact){shikiId=Number(exact.id)||0;break}
    }
    if(shikiId&&cacheKey){try{localStorage.setItem(cacheKey,JSON.stringify({id:shikiId,at:Date.now()}))}catch(e){}}
   }
  }
  if(!shikiId)return;
  var detail=await fetchAnimeById(shikiId);
  if(request!==nextAiringRequest||!isRoute("title",d.id)||!document.getElementById("next-episode-info"))return;
  var at=detail&&detail.next_episode_at,episode=Number(detail&&detail.next_episode)||((Number(detail&&detail.episodes_aired)||0)+1);
  if(!at||!Number.isFinite(new Date(at).getTime())||!Number.isFinite(episode)||episode<1)return;
  var date=new Date(at),dateText=new Intl.DateTimeFormat("ru-RU",{day:"numeric",month:"long",year:date.getFullYear()!==new Date().getFullYear()?"numeric":undefined}).format(date);
  var timeText=new Intl.DateTimeFormat("ru-RU",{hour:"2-digit",minute:"2-digit"}).format(date);
  host.innerHTML='<span class="next-episode-icon" aria-hidden="true">◷</span><span class="next-episode-copy"><small>СЛЕДУЮЩАЯ СЕРИЯ · '+Math.floor(episode)+'-Я</small><strong>'+dateText+' · '+timeText+'</strong></span>';
  host.hidden=false;
 }catch(error){if(request===nextAiringRequest)console.warn("[AniWatch] Shikimori next episode lookup failed:",error)}
}

var animeExtraPending={},animeExtraMemory={},kodikEpisodePending={},kodikEpisodeMemory={};
function safeAnimeMediaUrl(value,base){
 try{var u=new URL(String(value||""),base||location.href);if(u.protocol==="http:"&&u.hostname==="img.youtube.com")u.protocol="https:";return u.protocol==="https:"||u.protocol==="http:"?u.href:""}catch(e){return ""}
}
async function loadKodikEpisodes(d){
 if(!d)return;
 var cacheId=Number(d.shikiId)||Number(d.id);
 if(!cacheId)return;
 var apply=data=>{
  d.kodikEpisodeCount=Math.max(Number(d.e)||0,Number(data.total)||0);
  d.kodikAvailableEpisodes=Number(data.available)||0;
  d.kodikEpisodeNumbers=data.numbers||[];
  if(isRoute("title",d.id)){
   var count=$("#title-count");if(count)count.textContent=epTotal(d)>0?epTotal(d)+" эпизодов":"Количество серий уточняется";
   var list=$(".title-episodes .eps");if(list)list.innerHTML=eps(d,0,true);
   document.querySelectorAll('[data-episode-progress="'+d.id+'"]').forEach(el=>{el.textContent=watchedFor(d.id).length+" / "+(epTotal(d)||"—")+" просмотрено"});
  }else if(isRoute("watch",d.id)){
   var list=$(".watch-episodes .eps");if(list)list.innerHTML=eps(d,Number(routeArgs()[1])||1);
   document.querySelectorAll('[data-episode-progress="'+d.id+'"]').forEach(el=>{el.textContent=watchedFor(d.id).length+" / "+(epTotal(d)||"—")+" просмотрено"});
   var toolbarTotal=$(".watch-toolbar > div span");if(toolbarTotal)toolbarTotal.textContent="из "+(epTotal(d)||"?");
  }
 };
 if(kodikEpisodeMemory[cacheId]){apply(kodikEpisodeMemory[cacheId]);return}
 if(kodikEpisodePending[cacheId])return kodikEpisodePending[cacheId];
 kodikEpisodePending[cacheId]=(async()=>{
  var releases=await searchKodikAnime(d);
  var candidates=releases.map(item=>{
   var numbers=[];
   Object.entries(item&&item.seasons||{}).forEach(([seasonKey,season])=>{
    Object.entries(season&&season.episodes||{}).forEach(([key,value])=>{
     var n=Number(value&&(value.episode??value.number)||key);
     if(Number.isFinite(n)&&n>0)numbers.push(n);
    });
   });
   numbers=[...new Set(numbers)].sort((a,b)=>a-b);
   return {numbers,total:numbers.length?Math.max(...numbers):0};
  }).filter(x=>x.total>0).sort((a,b)=>b.total-a.total);
  if(!candidates.length)return;
  var best=candidates[0],data={total:best.total,available:best.total,numbers:best.numbers};
  kodikEpisodeMemory[cacheId]=data;apply(data);
 })().catch(error=>console.warn("[AniWatch] Kodik episode metadata unavailable:",error)).finally(()=>{delete kodikEpisodePending[cacheId]});
 return kodikEpisodePending[cacheId];
}
function renderAnimeDescription(d,description){
 var node=$("#td");if(!node||!isRoute("title",d.id))return;
 var value=cleanDesc(description||"");
 node.textContent=value||"Описание пока недоступно.";
 var expanded=value.length>260;
 node.classList.toggle("collapsed",expanded);
 var toggle=node.parentElement&&node.parentElement.querySelector(".desc-toggle");
 if(expanded&&!toggle){
  toggle=document.createElement("button");toggle.type="button";toggle.className="desc-toggle";toggle.dataset.a="desc";toggle.setAttribute("aria-expanded","false");toggle.textContent="Читать полностью";
  node.insertAdjacentElement("afterend",toggle);
 }else if(!expanded&&toggle)toggle.remove();
}
function renderAnimeExtras(d,data){
 var host=$("#anime-extra-sections");if(!host||!isRoute("title",d.id))return;
 renderAnimeDescription(d,data.description);
 var videos=Array.isArray(data.videos)?data.videos:[];
 var screenshots=Array.isArray(data.screenshots)?data.screenshots:[];
 var scoreStats=Array.isArray(data.rates_scores_stats)?data.rates_scores_stats:[];
 var trailerKinds=["pv","character_trailer","cm","clip","episode_preview"];
 var trailer=videos.slice().sort((a,b)=>trailerKinds.indexOf(String(a.kind||"").toLowerCase())-trailerKinds.indexOf(String(b.kind||"").toLowerCase())).find(v=>trailerKinds.includes(String(v.kind||"").toLowerCase())&&safeAnimeMediaUrl(v.player_url||v.playerUrl||v.url));
 var videoHtml="";
 if(trailer){
  var trailerUrl=safeAnimeMediaUrl(trailer.player_url||trailer.playerUrl||trailer.url),trailerImage=safeAnimeMediaUrl(trailer.image_url||trailer.imageUrl);
  videoHtml='<section class="anime-media-section"><div class="anime-media-heading"><h2>Трейлер</h2><span>Нажми, чтобы увеличить</span></div><div class="anime-video-grid"><button type="button" class="anime-video-card" data-a="anime-media-open" data-src="'+esc(trailerUrl)+'" data-kind="video" data-title="'+esc(trailer.name||"Трейлер")+'">'+(trailerImage?'<img src="'+esc(trailerImage)+'" alt="" loading="lazy">':'<span class="anime-video-placeholder">▶</span>')+'<span class="anime-video-caption">'+esc(trailer.name||"Смотреть трейлер")+'</span><span class="anime-video-play">▶</span></button><a class="anime-trailer-open" href="'+esc(trailerUrl)+'" target="_blank" rel="noopener noreferrer">Открыть трейлер ↗</a></div></section>';
 }
 var ratingHtml="";
 if(scoreStats.length){
  var rows=scoreStats.map(x=>({score:Number(x.score)||0,count:Math.max(0,Number(x.count)||0)})).filter(x=>x.score>0&&x.count>0).sort((a,b)=>b.score-a.score).slice(0,10);
  var total=rows.reduce((sum,x)=>sum+x.count,0),max=Math.max(1,...rows.map(x=>x.count));
  if(rows.length)ratingHtml='<section class="anime-rating-section"><div class="anime-media-heading"><h2>Оценки зрителей</h2><span>'+total.toLocaleString("ru-RU")+' голосов</span></div><div class="anime-rating-layout"><div class="anime-rating-score"><b>'+(Number(data.score)||Number(d.r)||0).toFixed(1)+'</b><span>средняя оценка</span></div><div class="anime-rating-bars">'+rows.map(x=>'<div class="anime-rating-row"><span>'+x.score+'</span><i><b style="width:'+Math.round(x.count/max*100)+'%"></b></i><small>'+x.count.toLocaleString("ru-RU")+'</small></div>').join("")+'</div></div></section>';
 }
 var shots=screenshots.map(x=>{
  if(typeof x==="string"){var url=safeAnimeMediaUrl(x);return{full:url,preview:url}}
  x=x||{};
  var full=safeAnimeMediaUrl(x.original||x.original_url||x.originalUrl||x.url||x.src||x.image_url||x.imageUrl,"https://shikimori.io/");
  var preview=safeAnimeMediaUrl(x.preview||x.x332||x.x166||x.preview_url||x.previewUrl||x.original||x.original_url||x.originalUrl||x.url||x.src||x.image_url||x.imageUrl,"https://shikimori.io/");
  return{full:full,preview:preview};
 }).filter(x=>x.full&&x.preview).slice(0,12);
 var shotHtml=shots.length?'<section class="anime-media-section"><div class="anime-media-heading"><h2>Кадры</h2><span>'+shots.length+' · нажми, чтобы увеличить</span></div><div class="anime-screenshot-grid">'+shots.map((x,index)=>'<button type="button" class="anime-screenshot-card" data-a="anime-media-open" data-src="'+esc(x.full)+'" data-title="Кадр '+(index+1)+'"><img src="'+esc(x.preview)+'" alt="Кадр из аниме" loading="lazy"></button>').join("")+'</div></section>':"";
 host.innerHTML=videoHtml+ratingHtml+shotHtml;
 host.hidden=!host.innerHTML;
}
function loadAnimeExtras(d){
 var host=$("#anime-extra-sections");if(!host)return;
 var cacheId=Number(d.shikiId)||Number(d.id),now=Date.now(),key="aw-anime-detail-v1-"+cacheId;
 if(animeExtraMemory[cacheId]&&typeof animeExtraMemory[cacheId].description==="string"){renderAnimeExtras(d,animeExtraMemory[cacheId]);return}
 try{
  var saved=JSON.parse(localStorage.getItem(key)||"null");
  if(saved&&now-Number(saved.at)<86400000&&saved.data&&typeof saved.data.description==="string"){animeExtraMemory[cacheId]=saved.data;renderAnimeExtras(d,saved.data);return}
 }catch(e){}
 if(animeExtraPending[cacheId])return;
 animeExtraPending[cacheId]=(async()=>{
  var id=Number(d.shikiId)||(Number(d.id)>=1000000000?Number(d.id)-1000000000:0);
  if(!id&&Number(d.mal)>0){
   try{
    var matches=await fetchCatalogPage({query:un(d.n),page:1,limit:50,order:"popularity"});
    var exact=matches.find(item=>Number(item.mal_id)===Number(d.mal));
    id=Number(exact&&exact.id)||0;
   }catch(resolveError){console.warn("[AniWatch] Shikimori ID resolution failed:",resolveError)}
  }
  if(!id){renderAnimeDescription(d,"");return}
  var raw=await fetchAnimeById(id);
  var screenshots=Array.isArray(raw.screenshots)?raw.screenshots.slice(0,16):[];
  var data={
   videos:Array.isArray(raw.videos)?raw.videos.slice(0,24):[],
   screenshots:screenshots,
   rates_scores_stats:Array.isArray(raw.rates_scores_stats)?raw.rates_scores_stats:(Array.isArray(raw.scores_stats)?raw.scores_stats:(Array.isArray(raw.scoresStats)?raw.scoresStats:[])),
   score:Number(raw.score)||Number(d.r)||0,
   description:cleanDesc(raw.description_html||raw.description||"")
  };
  animeExtraMemory[cacheId]=data;
  try{localStorage.setItem(key,JSON.stringify({at:Date.now(),data:data}))}catch(e){}
  renderAnimeExtras(d,data);
 })().catch(error=>console.warn("[AniWatch] Anime media metadata unavailable:",error)).finally(()=>{delete animeExtraPending[cacheId]});
}
async function loadAnimeGenres(anime){
 const shikiId=Number(anime&&anime.shikiId)||0;
 const container=app.querySelector(".title-tags");
 if(!shikiId||!container)return;
 try{
  const genres=await fetchDedicatedAnimeGenres(shikiId);
  if(!isRoute("title",anime.id)||!app.querySelector(".title-tags"))return;
  anime.g=genres;
  const target=app.querySelector(".title-tags");
  target.innerHTML=genres.length?genres.map(genre=>"<span>"+esc(genre)+"</span>").join(""):'<span class="genre-empty">Жанры не указаны</span>';
 }catch(error){console.warn("[AniWatch] Dedicated genre lookup failed:",error)}
}
V.title=p=>{
 var d=M[p[0]];if(!d)return renderMissing();
 document.title=htmlText(d.n)+" — AniWatch";
 renderAnimePage({app,anime:d,state:S,lists:LISTS,cleanDescription:cleanDesc,escapeHtml:esc,background:bg,backdrop:bn,episodes:(anime,cur)=>eps(anime,cur,true),watchUrl});
 setupEpisodeNavigator(d);
 loadNextEpisode(d);loadAnimeGenres(d);loadAnimeExtras(d);loadKodikEpisodes(d);ru(d);loadRelated(d)
};


function setupEpisodeNavigator(anime){
 var host=$("#episode-range-list"),input=$("#episode-jump");if(!host||!input)return;
 var total=epTotal(anime),watched=watchedFor(anime.id),last=Number(S.hist&&S.hist[anime.id]&&S.hist[anime.id].ep)|| (watched.length?Math.max(...watched):0);
 input.max=String(total||"");
 var ranges=[];for(var start=1;start<=total;start+=100){var end=Math.min(total,start+99);ranges.push('<button type="button" class="episode-range-btn" data-a="episode-range" data-from="'+start+'" data-to="'+end+'">'+start+'–'+end+'</button>')}
 host.innerHTML=ranges.join("");
 var target=last||1,from=Math.floor((target-1)/100)*100+1,to=Math.min(total,from+99);
 applyEpisodeRange(from,to);
}
function applyEpisodeRange(from,to){
 var items=document.querySelectorAll(".title-episodes .eps .episode-item");
 items.forEach(function(item,index){var number=index+1;item.hidden=number<from||number>to});
 document.querySelectorAll(".episode-range-btn").forEach(function(button){var active=Number(button.dataset.from)===from;button.classList.toggle("on",active);button.setAttribute("aria-pressed",String(active))});
 var host=$("#episode-range-list");if(host)host.dataset.activeFrom=String(from);
}
function jumpToEpisode(value,animeId){
 var anime=M[Number(animeId)]||M[routeArgs()[0]],n=Math.floor(Number(value));
 if(!anime||!Number.isFinite(n)||n<1||n>epTotal(anime)){toast("Такого номера серии нет");return}
 var available=availableEpCount(anime);
 if(available!==null&&n>available){toast("Эта серия ещё не вышла");return}
 location.href=watchUrl(anime.id,n);
}

var ROOM_CONNECTED=false,ROOM_LAST_SYNC=0,STREAM_PLAYER=null,INLINE_STREAM_PLAYER=null,ROOM_CLOCK_OFFSET=0,ROOM_CLOCK_READY=false,ROOM_CLOCK_TIMER=null,ROOM_CLOCK_ID=Math.random().toString(36).slice(2);
function broadcastPlayback(type){
 if(!ROOM_CONNECTED||!P)return;
 var media=STREAM_PLAYER&&STREAM_PLAYER.getPlaybackState?STREAM_PLAYER.getPlaybackState():null;
 var state=media||{time:P.t,playing:P.on,speed:P.sp||1};
 sendRoomEvent(type||"playback",{animeId:P.d.id,episode:P.n,time:state.time,duration:state.duration,playing:state.playing,speed:state.speed,translationId:state.translationId??null,translationTitle:state.translationTitle||"",host:true}).catch(e=>console.warn("[AniWatch] Playback broadcast failed:",e))
}
function connectWatchParty(){
 ROOM_CONNECTED=false;
 var status=$("#room-status"),online=$("#room-online");
 if(status)status.textContent="Подключение…";
 connectRoom(S.room,{name:S.name||"Гость",host:!!S.roomHost,
  onStatus:(state,error)=>{if(status)status.textContent=state==="connected"?"На связи":"Нет связи";if(state==="error")console.warn("[AniWatch] Room status:",error)},
  onPresence:presence=>{var users=Object.values(presence||{}).flat(),count=users.length,hostOnline=users.some(user=>user&&user.host);if(online)online.textContent=count+" "+(count===1?"участник":count<5?"участника":"участников");if(status)status.textContent=S.roomHost?"Вы ведущий":hostOnline?"Ведущий на связи":"Ожидание ведущего"},
  onEvent:payload=>{
   if(payload.type==="clock-ping"&&S.roomHost){sendRoomEvent("clock-pong",{echo:Number(payload.clientTime)||0,hostTime:Date.now(),pingId:payload.pingId,host:true}).catch(()=>{});return}
   if(payload.type==="clock-pong"&&!S.roomHost&&payload.pingId===ROOM_CLOCK_ID){var receivedAt=Date.now(),sentAt=Number(payload.echo)||receivedAt,hostAt=Number(payload.hostTime)||receivedAt;if(receivedAt>=sentAt&&receivedAt-sentAt<5000){ROOM_CLOCK_OFFSET=hostAt-((sentAt+receivedAt)/2);ROOM_CLOCK_READY=true}return}
   if(payload.type==="request-state"&&S.roomHost){broadcastPlayback("state");return}
   if(payload.type==="chat"){var empty=$("#ms .chat-empty");if(empty)empty.remove();msg(payload.name||"Гость",String(payload.text||"").slice(0,500));return}
   if(payload.type==="episode-change"||payload.type==="translation-change"||payload.type==="state"||payload.type==="playback"){
    if(S.roomHost||!payload.host||!P||!payload.animeId)return;
    if(Number(payload.animeId)!==Number(P.d.id)||Number(payload.episode)!==Number(P.n)){
     var target=watchUrl(Number(payload.animeId),Number(payload.episode)||1)+"&room="+encodeURIComponent(S.room);
     if(location.href.indexOf(target.split("#")[0])<0)location.href=target;
     return;
    }
    var hostNow=Date.now()+(ROOM_CLOCK_READY?ROOM_CLOCK_OFFSET:0),drift=Math.max(0,(hostNow-Number(payload.sentAt||hostNow))/1000);
    P.t=Math.max(0,Number(payload.time)||0)+(payload.playing?drift*(Number(payload.speed)||1):0);
    P.on=!!payload.playing;P.sp=Number(payload.speed)||1;
    var roomMedia={time:P.t,duration:Number(payload.duration)||0,playing:P.on,speed:P.sp};
    if(payload.translationId&&STREAM_PLAYER&&STREAM_PLAYER.syncTranslation){
     STREAM_PLAYER.syncTranslation(payload.translationId,roomMedia).then(function(changed){
      if(changed&&STREAM_PLAYER&&STREAM_PLAYER.syncPlayback)STREAM_PLAYER.syncPlayback(roomMedia);
     }).catch(function(error){console.warn("[AniWatch] Room translation sync failed:",error)});
    }else if(STREAM_PLAYER&&STREAM_PLAYER.syncPlayback)STREAM_PLAYER.syncPlayback(roomMedia);
    var speed=$("#sp");if(speed)speed.textContent=P.sp+"×";
   }
  }
 }).then(()=>{
  ROOM_CONNECTED=true;ROOM_LAST_SYNC=Date.now();
  if(ROOM_CLOCK_TIMER)clearInterval(ROOM_CLOCK_TIMER);
  if(!S.roomHost){var pingClock=()=>{if(ROOM_CONNECTED)sendRoomEvent("clock-ping",{clientTime:Date.now(),pingId:ROOM_CLOCK_ID}).catch(()=>{})};pingClock();ROOM_CLOCK_TIMER=setInterval(pingClock,5000)}else{ROOM_CLOCK_OFFSET=0;ROOM_CLOCK_READY=true}
  var empty=$("#ms .chat-empty");if(empty)empty.remove();
  msg("AniWatch","Вы подключились к комнате.");
  if(S.roomHost)broadcastPlayback("state");
  else sendRoomEvent("request-state",{name:S.name||"Гость"}).catch(()=>{});
 }).catch(error=>{ROOM_CONNECTED=false;if(status)status.textContent="Не удалось подключиться";console.error("[AniWatch] Room connect failed:",error);toast("Не удалось подключиться к комнате")});
}
function tick(s){if(!P)return;P.t=Math.min(DUR,P.t+s);if(P.t>=DUR){P.on=false;return nextEp()}
 var tc=$("#tc"),pg=$("#pg"),pl=$(".play");if(!tc||!pg||!pl)return;tc.textContent=fm(P.t);pg.style.width=P.t/DUR*100+"%";pl.textContent=P.on?"❚❚":"▶";if(s){S.hist[P.d.id]={ep:P.n,t:P.t,at:Date.now()};if(!tick.l||Date.now()-tick.l>5000){tick.l=Date.now();sv()}}
 if(P.on&&ROOM_CONNECTED&&Date.now()-ROOM_LAST_SYNC>8000){ROOM_LAST_SYNC=Date.now();broadcastPlayback("playback")}}
function pauseSave(){if(P&&!P.on&&P.t>0){S.hist[P.d.id]={ep:P.n,t:P.t,at:Date.now()};sv()}}
function nextEp(){var d=P.d,n=P.n,tot=epTotal(d);setEpisodeWatched(d.id,n,true);if(n<tot){S.hist[d.id]={ep:n+1,t:0,at:Date.now()};sv();try{sessionStorage.setItem("aw.ap","1")}catch(e){}location.href=watchUrl(d.id,n+1)}else if(!tot){S.hist[d.id]={ep:n,t:0,at:Date.now()};sv();toast("Серия закончилась");$(".play").textContent="▶"}else{delete S.hist[d.id];sv();toast("Тайтл досмотрен 🎉");$(".play").textContent="▶"}}
V.watch=p=>{
 var d=M[p[0]];if(!d)return renderMissing();
 loadKodikEpisodes(d);
 var queryRoom=new URLSearchParams(location.search).get("room");
 if(queryRoom){var normalized=queryRoom.toUpperCase().replace(/[^A-Z0-9]/g,"").slice(0,12),guestInvite=new URLSearchParams(location.search).get("guest")==="1",roomChanged=S.room!==normalized;if(roomChanged||guestInvite){S.room=normalized;if(roomChanged||guestInvite)S.roomHost=false;S.roomAnime=d.id;sv()}}
 var n=Math.max(p[1]||1,1),h=S.hist[d.id],available=availableEpCount(d);if(epTotal(d)>0)n=Math.min(n,epTotal(d));if(available!==null&&n>available){document.title=htmlText(d.n)+" · серия ещё не вышла — AniWatch";app.innerHTML='<section class="offline-state"><div class="eyebrow">СКОРО</div><h1>Эта серия ещё не вышла</h1><p>Сейчас доступно '+available+' серий. Вернись позже, когда выйдет серия '+n+'.</p><a class="btn" href="'+titleUrl(d.id)+'">Вернуться к аниме</a></section>';return}document.title=htmlText(d.n)+" · серия "+n+" — AniWatch";
 var inRoom=!!S.room;if(inRoom){S.roomAnime=d.id;S.roomEpisode=n;sv()}
 P={d:d,n:n,t:h&&h.ep==n?h.t:0,on:readAutoplay(),sp:h&&h.ep==n&&Number(h.speed)>0?Number(h.speed):1};
 // External iframe players cannot expose playback events; save the selected title/episode without inventing a time or percentage.
 recordWatchEntry(d,n);
 renderWatchPage({app,anime:d,episode:n,inRoom,state:S,escapeHtml:esc,backdrop:bn,episodes:eps,episodeTotal:epTotal});
 var historySaveAt=0;
 STREAM_PLAYER=mountStreamPlayer({root:$("#stream-player"),anime:d,episode:n,resumeAt:P.t,resumeSpeed:P.sp,onEpisodeChange:async change=>{if(!inRoom||!S.roomHost||!change||!Number(change.episode)||Number(change.episode)===n)return;var next=Math.floor(Number(change.episode));await sendRoomEvent("episode-change",{animeId:d.id,episode:next,host:true});location.href=watchUrl(d.id,next)+"&room="+encodeURIComponent(S.room)},onTranslationChange:change=>{if(!inRoom||!S.roomHost||!change||!change.translationId)return;sendRoomEvent("translation-change",{animeId:d.id,episode:n,translationId:change.translationId,translationTitle:change.title||"",time:change.time,duration:change.duration,playing:change.playing,speed:change.speed,host:true}).catch(error=>console.warn("[AniWatch] Room translation broadcast failed:",error))},onReady:()=>{if(inRoom){if(S.roomHost)broadcastPlayback("state");else sendRoomEvent("request-state",{name:S.name||"Гость"}).catch(()=>{})}},onEpisodeEnded:()=>{setEpisodeWatched(d.id,n,true);var nextAvailable=availableEpCount(d);if(nextAvailable!==null&&n<nextAvailable&&S.autoNextEpisode!==false){S.hist[d.id]={ep:n+1,t:0,at:Date.now(),speed:P.sp||1};sv();try{sessionStorage.setItem("aw.ap","1")}catch(e){}setTimeout(()=>{location.href=watchUrl(d.id,n+1)+(inRoom?"&room="+encodeURIComponent(S.room):"")},250)}else{if(nextAvailable===null||n>=nextAvailable)delete S.hist[d.id];sv();toast(nextAvailable!==null&&n<nextAvailable?"Серия завершена. Автопереход отключён.":"Серия завершена")}},onPlayback:media=>{
  // Save real HTML5 player progress; the legacy custom-player tick is not used here.
  var now=Date.now(),time=Math.max(0,Number(media.time)||0);
  if(time>0){
   S.hist[d.id]={ep:n,t:time,duration:Math.max(0,Number(media.duration)||0),at:now,speed:Number(media.speed)||1};
   P.t=time;P.on=!!media.playing;P.sp=Number(media.speed)||1;
   if(now-historySaveAt>=5000||!media.playing){historySaveAt=now;sv()}
  }
  if(!ROOM_CONNECTED||!S.roomHost)return;
  if(now-ROOM_LAST_SYNC<650&&media.playing)return;ROOM_LAST_SYNC=now;
  sendRoomEvent("playback",{animeId:d.id,episode:n,time:media.time,duration:media.duration,playing:media.playing,speed:media.speed,translationId:media.translationId??null,translationTitle:media.translationTitle||"",host:true}).catch(e=>console.warn("[AniWatch] Player sync failed:",e));
 }});
 loadBanner(d);
 if(inRoom)connectWatchParty();
};

async function loadTogetherView(){
 var request=++socialLoadRequest;
 app.innerHTML='<p class="empty">Загружаем друзей и приглашения…</p>';
 try{
  if(!AUTH_USER){var auth=await initializeSupabaseAuth();AUTH_USER=auth.user;if(AUTH_USER){S=await restoreCloudState(S,AUTH_USER.id);saveLocalState(S,M)}}
  if(request!==socialLoadRequest||activePage()!=="together")return;
  if(!AUTH_USER){
   if(socialChannelCleanup){socialChannelCleanup();socialChannelCleanup=null}
   renderTogetherPage({app,state:S,animeList:D,escapeHtml:esc,user:null,social:null});
   return;
  }
  // Subscribe before reading the snapshot so changes cannot be lost between
  // the initial query and the Realtime connection.
  if(socialChannelCleanup){socialChannelCleanup();socialChannelCleanup=null}
  var requestCleanup=null;
  try{
   requestCleanup=await subscribeSocialUpdates(AUTH_USER.id,()=>{
    if(activePage()!=="together"||socialRefreshPending)return;
    socialRefreshPending=true;
    setTimeout(()=>{socialRefreshPending=false;if(activePage()==="together")loadTogetherView()},350);
   });
  }catch(realtimeError){
   console.warn("[AniWatch] Social Realtime unavailable; manual refresh remains available:",realtimeError);
  }
  if(request!==socialLoadRequest||activePage()!=="together"){
   if(requestCleanup)requestCleanup();
   return;
  }
  socialChannelCleanup=requestCleanup;
  var social=await loadSocialHub(AUTH_USER.id);
  if(request!==socialLoadRequest||activePage()!=="together")return;
  renderTogetherPage({app,state:S,animeList:D,escapeHtml:esc,user:AUTH_USER,social});
 }catch(error){
  console.error("[AniWatch] Social hub failed:",error);
  if(request===socialLoadRequest&&activePage()==="together")renderTogetherPage({app,state:S,animeList:D,escapeHtml:esc,user:AUTH_USER,social:{friends:[],incomingRequests:[],outgoingRequests:[],incomingInvites:[],outgoingInvites:[]},error:error.message||"Не удалось загрузить друзей."});
 }
}
V.together=()=>loadTogetherView();
async function openRoomInvitePanel(){
 var panel=$("#room-invite-panel"),host=$("#room-invite-friend-list");
 if(!panel||!host)return;
 if(panel.hidden===false){panel.hidden=true;return}
 if(!AUTH_USER){try{var auth=await initializeSupabaseAuth();AUTH_USER=auth.user;if(AUTH_USER)S=await restoreCloudState(S,AUTH_USER.id)}catch(error){console.warn("[AniWatch] Auth refresh failed:",error)}}
 if(!AUTH_USER){openAuthModal();toast("Войди в аккаунт, чтобы приглашать друзей");return}
 panel.hidden=false;host.innerHTML='<p class="social-empty">Загружаем друзей…</p>';
 try{
  var social=await loadSocialHub(AUTH_USER.id);
  if(!P||!S.room){host.innerHTML='<p class="social-empty">Комната больше не активна. Создай новую.</p>';return}
  host.innerHTML=social.friends.length?social.friends.map(friend=>{
   var avatar=friend.avatar_url&&/^https:\/\//i.test(friend.avatar_url)?'<img src="'+esc(friend.avatar_url)+'" alt="">':'<span>'+esc(String(friend.username||"?").slice(0,1).toUpperCase())+'</span>';
   return '<article class="social-person"><div class="social-avatar">'+avatar+'</div><div class="social-person-info"><b>'+esc(friend.username)+'</b><small>Друг</small></div><button class="btn" type="button" data-a="room-send-invite" data-id="'+esc(friend.id)+'">Пригласить</button></article>';
  }).join(""):'<p class="social-empty">У тебя пока нет друзей. Добавь их во вкладке «Вместе».</p>';
 }catch(error){host.innerHTML='<p class="social-error">'+esc(error.message||"Не удалось загрузить друзей.")+'</p>'}
}
async function searchCollectionAnime(query){
 var host=$("#collection-anime-search-results"),q=String(query||"").trim(),request=++collectionSearchRequest;if(!host)return;
 if(q.length<2){host.innerHTML='<p class="profile-hint">Введи минимум 2 символа для поиска.</p>';return}
 host.innerHTML='<p class="profile-hint">Ищем аниме…</p>';
 try{
  var raw=await fetchCatalogPage({query:q,page:1,limit:30,order:"popularity"});
  if(request!==collectionSearchRequest||!$("#collection-anime-search-results"))return;
  var list=(Array.isArray(raw)?raw:[]).map(shikiToItem).filter(x=>x&&Number(x.shikiId)>0);
  list.forEach(d=>{M[d.id]=d;S.shikiAnime=S.shikiAnime||{};S.shikiAnime[d.id]=d});
  await xshikiPosters(list);if(request!==collectionSearchRequest)return;host=$("#collection-anime-search-results");if(!host)return;
  host.innerHTML=list.length?list.map(d=>'<article class="collection-search-result"><div class="collection-search-poster">'+(shikiImageUrl(d.img)?'<img src="'+esc(d.img)+'" alt="" loading="lazy">':'<span>AW</span>')+'</div><div class="collection-search-info"><b>'+esc(un(d.n))+'</b><small>'+esc(d.y||"Год неизвестен")+' · '+esc((d.g||[]).slice(0,2).join(", "))+'</small></div><button type="button" class="btn collection-search-add" data-a="collection-add-search-item" data-id="'+d.id+'">Добавить</button></article>').join(""):'<p class="profile-hint">Ничего не найдено. Попробуй другое название.</p>';
 }catch(error){if(request!==collectionSearchRequest)return;console.warn("[AniWatch] Collection anime search failed:",error);host.innerHTML='<p class="profile-hint">Не удалось выполнить поиск. Попробуй ещё раз.</p>'}
}
async function loadCollectionsView(params){
 app.innerHTML='<p class="empty">Загружаем коллекции…</p>';
 try{
  var id=params&&params[0],currentUserId=AUTH_USER?.id||null;
  if(id){var detail=await getCollection(id);detail.items.forEach(item=>{if(item.anime_data&&!M[item.anime_id])M[item.anime_id]=item.anime_data});renderCollectionsPage({app,detail,user:AUTH_USER,animeList:Object.values(M),currentUserId});xshikiPosters(detail.items.map(item=>M[item.anime_id]).filter(Boolean));}
  else{var collections=await listCollections(currentUserId);renderCollectionsPage({app,collections,user:AUTH_USER,animeList:Object.values(M),currentUserId});}
 }catch(error){console.error("[AniWatch] Collections load failed:",error);app.innerHTML='<section class="offline-state"><h1>Не удалось загрузить коллекции</h1><p>Проверь подключение и попробуй ещё раз.</p><button class="btn" data-a="collections-reload">Повторить</button></section>'}
}
V.collections=loadCollectionsView;
function collectionPosterItems(){
 var ids=new Set([...(S.fav||[]).map(Number)]),raw=S.watchlist||{};
 if(Array.isArray(raw))raw.forEach(item=>{var id=Number(item&&(item.id??item.anime_id??item.animeId));if(id>0)ids.add(id)});
 else Object.keys(raw).forEach(id=>{if(Number(id)>0)ids.add(Number(id))});
 return [...ids].map(id=>M[id]||S.shikiAnime&&S.shikiAnime[id]).filter(Boolean);
}
V.favorites=()=>{renderFavorites({app,state:S,mediaMap:M,card:d=>card(d,animeProgress(d))});xshikiPosters(collectionPosterItems()).catch(error=>console.warn("[AniWatch] Collection poster enrichment failed:",error))};
async function refreshMyListFromCloud(){
 if(!AUTH_USER)return;
 if(myListCloudPromise)return myListCloudPromise;
 var userId=AUTH_USER.id;
 myListCloudPromise=(async()=>{
  var merged=await restoreCloudState(S,userId);
  if(!AUTH_USER||AUTH_USER.id!==userId)return;
  S=merged;
  await xhyd();
  saveLocalState(S,M);
  myListCloudAt=Date.now();
 })().finally(()=>{myListCloudPromise=null});
 return myListCloudPromise;
}
V.mylist=()=>{
 var request=++myListRenderRequest;
 var render=()=>{
  if(request!==myListRenderRequest||activePage()!=="mylist")return;
  renderMyList({app,state:S,mediaMap:M,filters:F,lists:LISTS,card:d=>card(d,animeProgress(d))});
  xshikiPosters(collectionPosterItems()).catch(error=>console.warn("[AniWatch] Collection poster enrichment failed:",error));
 };
 if(!AUTH_USER||Date.now()-myListCloudAt<15000){render();return}
 render();
 var syncNotice=app.querySelector(".personal-list-page");
 if(syncNotice)syncNotice.insertAdjacentHTML("afterbegin",'<p class="empty" role="status">Обновляем списки из аккаунта…</p>');
 refreshMyListFromCloud().then(render).catch(error=>{
  console.error("[AniWatch] My Lists cloud load failed:",error);
  if(request!==myListRenderRequest||activePage()!=="mylist")return;
  render();
  var page=app.querySelector(".personal-list-page");
  if(page)page.insertAdjacentHTML("afterbegin",'<p class="empty" role="status">Не удалось обновить данные из БД. Ниже показан сохранённый локальный снимок. <button class="btn ghost" type="button" data-a="mylist-reload">Повторить загрузку</button></p>');
 });
};
var calendarLoadRequest=0,calendarItems=[],calendarFollows={},calendarFilter="all",calendarSelectedDate="",calendarPushState={supported:false,enabled:false};
 function calendarPosterModels(items){
  return (items||[]).map(item=>{
   var shikiId=Number(item.shikimoriId),id=1000000000+shikiId;
   if(!Number.isInteger(shikiId)||shikiId<=0)return null;
   var d=M[id]||(S.shikiAnime&&S.shikiAnime[id]);
   if(!d){
    d={id,shikiId,source:"shikimori",mal:Number(item.malId)||null,n:String(item.title||"Без названия"),o:"",g:["Аниме"],y:Number(item.year)||0,r:0,e:0,s:"Онгоинг",d:"",c:["#7c3aed","#0f0f1a"],img:shikiImageUrl(item.poster),ban:"",kind:String(item.type||"").toLowerCase()};
   }else if(!shikiImageUrl(d.img)&&item.poster)d.img=shikiImageUrl(item.poster);
   if(!Number(d.mal)&&Number(item.malId)>0)d.mal=Number(item.malId);
   d.shikiId=shikiId;d.source=d.source||"shikimori";
   M[id]=d;S.shikiAnime=S.shikiAnime||{};S.shikiAnime[id]=d;
   return {item,d};
  }).filter(Boolean);
 }
 function calendarLibraryIds(){
  var ids=new Set((S.fav||[]).map(Number).filter(id=>Number.isSafeInteger(id)&&id>0)),watch=S.watchlist||{};
  if(Array.isArray(watch))watch.forEach(item=>{var id=Number(item&&(item.id??item.anime_id??item.animeId));if(id>0)ids.add(id)});
  else Object.keys(watch).forEach(key=>{var id=Number(key);if(id>0)ids.add(id)});
  var shiki=new Set(),mal=new Set();
  ids.forEach(id=>{
   var d=M[id]||(S.shikiAnime&&S.shikiAnime[id]);
   var shikiId=Number(d&&d.shikiId)||(id>=1000000000?id-1000000000:0),malId=Number(d&&d.mal)||0;
   if(shikiId>0)shiki.add(shikiId);
   if(malId>0)mal.add(malId);
  });
  return {shiki:[...shiki],mal:[...mal]};
 }
 function renderCalendarCurrent(){
  var library=calendarLibraryIds();
  renderCalendarPage({app,items:calendarItems,filter:calendarFilter,selectedDate:calendarSelectedDate,libraryShikiIds:library.shiki,libraryMalIds:library.mal,follows:calendarFollows,loggedIn:!!AUTH_USER,pushState:calendarPushState});
 }
 async function loadCalendarFollowState(){
  if(AUTH_USER){
   try{
    var localFollows={...(S.calendarFollows||{})},cloudFollows=await loadCalendarFollows(AUTH_USER.id);
    for(var id of Object.keys(localFollows))if(!cloudFollows[id])await saveCalendarFollow(AUTH_USER.id,id,true);
    calendarFollows=await loadCalendarFollows(AUTH_USER.id);
    if(Object.keys(localFollows).length){S.calendarFollows={};saveLocalState(S,M)}
    return;
   }catch(error){console.warn("[AniWatch] Calendar follows could not be loaded:",error)}
  }
  calendarFollows={...(S.calendarFollows||{})};
 }
 async function loadCalendar(force=false){
  var request=++calendarLoadRequest;
  renderCalendarPage({app,loading:true});
  try{
   var items=await fetchShikimoriCalendar({force});
   var posterEntries=calendarPosterModels(items);
   if(posterEntries.length)await xshikiPosters(posterEntries.map(entry=>entry.d),{resolveMalIds:true});
   posterEntries.forEach(entry=>{entry.item.poster=shikiImageUrl(entry.d.img);entry.item.malId=Number(entry.d.mal)||Number(entry.item.malId)||0});
   calendarItems=items;
   await loadCalendarFollowState();
   try{calendarPushState=await getCalendarPushState()}catch(error){calendarPushState={supported:false,enabled:false}}
   if(request===calendarLoadRequest&&activePage()==="calendar")renderCalendarCurrent();
  }catch(error){
   console.warn("[AniWatch] Shikimori calendar failed:",error);
   if(request===calendarLoadRequest&&activePage()==="calendar")renderCalendarPage({app,error:"Не удалось загрузить расписание Shikimori. Попробуй ещё раз."});
  }
 }
 V.calendar=()=>loadCalendar(false);
 V.profile=async()=>{var targetId=routeArgs()[0];if(targetId&&(!AUTH_USER||targetId!==AUTH_USER.id)){app.innerHTML='<p class="empty">Загружаем профиль…</p>';try{var publicProfile=await fetchPublicProfile(targetId);if(!publicProfile){app.innerHTML='<p class="empty">Профиль недоступен или пользователь ограничил доступ.</p>';return}var publicIds=(publicProfile.favorite_ids||[]).map(Number);if(publicIds.length){try{(await fetchAnimeByIds(publicIds)).forEach(item=>{var d=shikiToItem(item);M[d.id]=d})}catch(error){console.warn("[AniWatch] Public profile favorites could not be hydrated:",error)}}if(activePage()==="profile")renderPublicProfile({app,profile:publicProfile,escapeHtml:esc,mediaMap:M})}catch(error){console.error("[AniWatch] Public profile load failed:",error);app.innerHTML='<p class="empty">Не удалось загрузить профиль. Попробуй позже.</p>'}return}renderProfile({app,state:S,mediaMap:M,escapeHtml:esc,user:AUTH_USER});if(AUTH_USER&&AUTH_USER.id==="a0cf372c-5d93-4899-ab5d-1fb507387c06"&&String(AUTH_USER.email||"").trim().toLowerCase()==="demid.prim@gmail.com"){app.insertAdjacentHTML("afterbegin",'<a class="site-stats-shortcut" href="stats.html"><span><b>Статистика сайта</b><small>demid.prim@gmail.com · панель владельца</small></span><strong>↗</strong></a>')}};
function openAuthModal(){
 if(AUTH_USER){location.href=PAGES.profile;return}
 if(document.getElementById("auth-modal"))return;
 var modal=document.createElement("div");
 modal.id="auth-modal";modal.className="auth-modal";modal.setAttribute("role","dialog");modal.setAttribute("aria-modal","true");modal.setAttribute("aria-labelledby","auth-modal-title");
 modal.innerHTML='<div class="auth-modal-backdrop" data-a="auth-close"></div><section class="auth-modal-panel"><button class="auth-modal-close" type="button" data-a="auth-close" aria-label="Закрыть">×</button><div class="auth-box"><div class="auth-heading"><span class="eyebrow">ANIWATCH ACCOUNT</span><h2 id="auth-modal-title">Смотри на любом устройстве</h2><p>Войди или создай аккаунт, чтобы синхронизировать избранное, списки и историю просмотра.</p></div><div class="auth-tabs"><button type="button" class="on" data-a="auth-mode" data-v="login" data-auth-mode="login">Вход</button><button type="button" data-a="auth-mode" data-v="signup" data-auth-mode="signup">Регистрация</button></div><form id="auth-form" class="auth-form" novalidate><input type="hidden" name="auth-mode" value="login"><label id="auth-username-wrap" hidden>Ник<input id="auth-username" type="text" maxlength="20" autocomplete="nickname" placeholder="Придумай уникальный ник"></label><label id="auth-login-wrap">Логин или электронная почта<input id="auth-login" type="text" autocomplete="username" placeholder="Ник или name@example.com" required></label><label id="auth-email-wrap" hidden>Электронная почта<input id="auth-email" type="email" autocomplete="email" placeholder="name@example.com"></label><label>Пароль<input id="auth-password" type="password" autocomplete="current-password" minlength="6" placeholder="Минимум 6 символов" required></label><button class="btn auth-submit" id="auth-submit" type="submit">Войти</button><p id="auth-message" class="auth-message" role="status" aria-live="polite"></p></form></div></section>';
 document.body.appendChild(modal);
 openDialog(modal);
 var login=document.getElementById("auth-login");if(login)login.focus();
}
async function handleAuthSubmit(form){
 if(AUTH_BUSY)return;
 var mode=form.querySelector("[name=auth-mode]")?.value||"login";
 var login=String($("#auth-login")?.value||"").trim(),email=String($("#auth-email")?.value||"").trim(),password=$("#auth-password")?.value||"",username=String($("#auth-username")?.value||"").trim();
 var status=$("#auth-message"),button=$("#auth-submit");
 if((mode==="signup"?!email:!login)||!password){if(status)status.textContent=mode==="signup"?"Заполни почту и пароль.":"Заполни логин и пароль.";return}
 if(mode==="signup"&&!username){if(status)status.textContent="Придумай ник.";return}
 if(mode==="signup"&&password.length<6){if(status)status.textContent="Пароль должен содержать минимум 6 символов.";return}
 AUTH_BUSY=true;if(button){button.disabled=true;button.textContent="Подождите…"}if(status)status.textContent="";
 try{
  var result=mode==="signup"?await signUpWithEmail(email,password,username):await signInWithEmail(login,password);
  // A user object may exist before email confirmation, but without a session
  // there is no authenticated JWT and RLS must reject library writes.
  AUTH_USER=result.session?.user||result.data?.session?.user||null;
  if(AUTH_USER){
   var signedInUserId=AUTH_USER.id;
   var initialName=mode==="signup"?username:AUTH_USER.user_metadata?.username;
   if(initialName&&(!S.name||S.name==="Гость"||S.name==="Аноним"))S.name=String(initialName).slice(0,20);
   saveLocalState(S,M);hd();
   var authModal=document.getElementById("auth-modal");if(authModal)closeDialog(authModal);
   toast(mode==="signup"?"Аккаунт создан":"Вход выполнен");

   // Authentication is complete. Load cloud data after closing the modal so
   // slow library/profile hydration never blocks the sign-in interaction.
   (async()=>{
    try{
     var restored=await restoreCloudState(S,signedInUserId);
     if(!AUTH_USER||AUTH_USER.id!==signedInUserId)return;
     S=restored;saveLocalState(S,M);
     await xhyd();myListCloudAt=Date.now();
     var cloudFeedback=await loadRecommendationFeedback(signedInUserId);
     S.recommendationDismissed={...(S.recommendationDismissed||{}),...cloudFeedback};
     Object.keys(S.recommendationDismissed).forEach(id=>{
      if(!cloudFeedback[id])saveRecommendationFeedback(signedInUserId,id).catch(error=>console.warn("[AniWatch] Recommendation feedback sync failed:",error));
     });
     saveLocalState(S,M);hd();
     if(activePage()==="home"){refreshContinueShelf();loadHomeRecommendations()}
     else if(activePage()==="profile")V.profile();else if(activePage()==="calendar")V.calendar();
     else if(activePage()==="mylist")V.mylist();
     else if(activePage()==="favorites")V.favorites();
     else if(activePage()==="together")loadTogetherView();
    }catch(error){
     console.error("[AniWatch] Background account sync failed:",error);
     if(AUTH_USER&&AUTH_USER.id===signedInUserId)toast("Вход выполнен, но синхронизация данных не завершилась");
    }
   })();
  }else if(status){status.textContent=mode==="signup"?"Регистрация завершена. Теперь войди в аккаунт.":"Не удалось получить активную сессию. Попробуй войти ещё раз."}
 }catch(error){console.error("[AniWatch] Auth error:",error);if(status)status.textContent=authErrorText(error)}
 finally{AUTH_BUSY=false;if(button){button.disabled=false;button.textContent=mode==="signup"?"Создать аккаунт":"Войти"}}
}
function authErrorText(error){
 var m=String(error?.message||"");
 if(/Invalid login credentials|Неверный логин или пароль/i.test(m))return "Неверный логин или пароль.";
 if(/User already registered/i.test(m))return "Аккаунт с такой почтой уже существует.";
 if(/Password should be at least/i.test(m))return "Пароль слишком короткий.";
 if(/Email not confirmed/i.test(m))return "Сначала подтверди почту по ссылке из письма.";
 if(/rate limit/i.test(m))return "Слишком много попыток. Попробуй позже.";
 return m||"Не удалось выполнить запрос. Попробуй ещё раз.";
}
async function handleAuthLogout(){
 try{
  await signOut();
  AUTH_USER=null;
  S.avatar="";
  saveLocalState(S,M);
  hd();
  toast("Вы вышли из аккаунта");
  if(socialChannelCleanup){socialChannelCleanup();socialChannelCleanup=null}
  if(activePage()==="together")loadTogetherView();else V.profile();
 }catch(error){console.error("[AniWatch] Sign out failed:",error);toast("Не удалось выйти из аккаунта")}
}

// ---- Реальные данные: AniList (постеры, баннеры, описания) + Shikimori (русские названия и описания) ----
var Q="query{Page(perPage:30){media(type:ANIME,sort:TRENDING_DESC,isAdult:false){id idMal title{romaji english}genres seasonYear startDate{year month}averageScore episodes status coverImage{extraLarge color}bannerImage}}}";
var GR={Action:"Экшен",Adventure:"Приключения",Comedy:"Комедия",Drama:"Драма",Fantasy:"Фэнтези",Romance:"Романтика",Mystery:"Детектив","Slice of Life":"Повседневность",Supernatural:"Сверхъестественное",Sports:"Спорт",Horror:"Ужасы",Mecha:"Меха",Music:"Музыка",Psychological:"Психология",Thriller:"Триллер"};
var ST={RELEASING:"Онгоинг",FINISHED:"Завершён",NOT_YET_RELEASED:"Скоро",CANCELLED:"Отменён",HIATUS:"Пауза"};
function mp(m){
 var title=m.title||{},genres=Array.isArray(m.genres)&&m.genres.length?m.genres:["Аниме"];
 var primary=title.english||title.romaji||title.native||"Без названия";
 var alternate=title.romaji&&title.romaji!==primary?title.romaji:(title.native&&title.native!==primary?title.native:"");
 return{id:m.id,aniId:m.id,source:"anilist",mal:m.idMal||null,n:esc(primary),o:esc(alternate),g:genres.map(g=>GR[g]||g),y:m.seasonYear||(m.startDate&&m.startDate.year)||0,r:m.averageScore?m.averageScore/10:0,e:Number(m.episodes)||0,s:ST[m.status]||"",d:"",c:["#7c3aed","#0f0f1a"],img:"",ban:typeof m.bannerImage==="string"?m.bannerImage:"",kind:String(m.format||"").toLowerCase()}
}

// AniList is the source of truth for catalog metadata and navigation IDs.
// Do not treat AniList MAL IDs as Shikimori IDs. They are different ID namespaces.
// AniList remains the source of truth; episode counts are enriched through MAL-aware services.
async function enrichShikimori(list){return list||[];}

function idx(){M={};D.forEach(d=>M[d.id]=d);var c={};D.forEach(d=>d.g.forEach(g=>c[g]=(c[g]||0)+1));GN=Object.keys(c).sort((a,b)=>c[b]-c[a]).slice(0,10);H=D.filter(d=>d.ban).slice(0,8);if(H.length<8){var featuredIds=new Set(H.map(d=>d.id));H=H.concat(D.filter(d=>!featuredIds.has(d.id)).slice(0,8-H.length))}}
var aniCountPending={};
async function anilibriaCount(d){
 if(!d)return;
 // Home releases already carry their AniLibria release ID and often episode total.
 // Avoid a redundant /search/releases title lookup when we already know the release.
 if(Number(d.e)>0){refreshEpCount(d);return}
 var cache=S.aniEpisodes=S.aniEpisodes||{},saved=cache[d.id];
 if(saved&&Date.now()-saved.at<6*36e5){d.e=Number(saved.total)||d.e;d.ae=Number(saved.available)||0;refreshEpCount(d);return}
 if(aniCountPending[d.id])return aniCountPending[d.id];
 aniCountPending[d.id]=(async()=>{
  var releaseId=Number(d.aniLibriaReleaseId)||0;
  if(!releaseId){
   var names=[un(d.n),un(d.o)].filter(Boolean),match=null;
   for(var q of names){
    try{
     var sr=await fetch("https://api.anilibria.app/api/v1/app/search/releases?query="+encodeURIComponent(q));
     if(!sr.ok)continue;
     var list=await sr.json();if(!Array.isArray(list))list=list.list||list.data||[];
     var wanted=names.map(normTitle).filter(Boolean);
     match=list.find(x=>{var n=x.name||{};return [n.main,n.english,n.alternative,x.name_ru,x.name_en].some(v=>wanted.includes(normTitle(v)))});
     if(match)break;
    }catch(e){}
   }
   releaseId=Number(match&&match.id)||0;
  }
  if(!releaseId)return;
  try{
   var rr=await fetch("https://api.anilibria.app/api/v1/anime/releases/"+encodeURIComponent(releaseId));
   if(!rr.ok)return;
   var data=await rr.json(),total=Number(data.episodes_count||data.episodes_total||(data.type&&data.type.episodes)||0);
   var available=Array.isArray(data.episodes)?data.episodes.length:0;
   if(!total&&data.episodes&&typeof data.episodes==="object")available=Object.keys(data.episodes).length;
   if(!total&&!available)return;
   cache[d.id]={total:total,available:available,at:Date.now()};sv();
   if(total)d.e=total;d.ae=available;refreshEpCount(d);
  }catch(e){}
 })();
 await aniCountPending[d.id];delete aniCountPending[d.id];
}
var aniZipPending={};
async function aniZipCount(d){
 if(!Number(d.id))return 0;
 var cache=S.aniZipEpisodes=S.aniZipEpisodes||{},saved=cache[d.id];
 if(saved&&Date.now()-saved.at<6*36e5){if(!d.e&&saved.total>0)d.e=saved.total;if(!d.ae&&saved.available>0)d.ae=saved.available;refreshEpCount(d);return saved.total||saved.available}
 if(aniZipPending[d.id])return aniZipPending[d.id];
 aniZipPending[d.id]=(async()=>{
  try{
   var res=await fetch("https://api.ani.zip/v1/episodes?anilist_id="+encodeURIComponent(d.id));
   if(!res.ok)return 0;
   var data=await res.json(),total=Number(data.episodeCount)||0,episodes=data.episodes||{},available=Object.keys(episodes).filter(k=>/^\d+$/.test(k)).length;
   if(!total&&!available)return 0;
   cache[d.id]={total:total,available:available,at:Date.now()};sv();
   if(total&&!d.e)d.e=total;
   if(!total&&available&&!d.ae)d.ae=available;
   refreshEpCount(d);return total||available;
  }catch(e){return 0}
 })();
 var result=await aniZipPending[d.id];delete aniZipPending[d.id];return result;
}
var kitsuPending={};
async function kitsuCount(d){
 if(!d.mal)return 0;
 var cache=S.kitsuEpisodes=S.kitsuEpisodes||{},saved=cache[d.mal];
 if(saved&&Date.now()-saved.at<6*36e5){if(!d.e&&saved.total>0)d.e=saved.total;if(!d.ae&&saved.available>0)d.ae=saved.available;refreshEpCount(d);return saved.total||saved.available}
 if(kitsuPending[d.mal])return kitsuPending[d.mal];
 kitsuPending[d.mal]=(async()=>{
  try{
   var map=await fetch("https://api.ani.zip/mappings?mal_id="+encodeURIComponent(d.mal));
   if(!map.ok)return 0;
   var mj=await map.json(),kid=mj.kitsu_id||(mj.mappings&&mj.mappings.kitsu_id);
   if(!kid)return 0;
   var [animeRes,epRes]=await Promise.all([
    fetch("https://kitsu.io/api/edge/anime/"+encodeURIComponent(kid)),
    fetch("https://kitsu.io/api/edge/episodes?filter%5BmediaType%5D=Anime&filter%5BmediaId%5D="+encodeURIComponent(kid)+"&page%5Blimit%5D=1")
   ]);
   var total=0,available=0;
   if(animeRes.ok){var ad=await animeRes.json();total=Number(ad.data&&ad.data.attributes&&ad.data.attributes.episodeCount)||0}
   if(epRes.ok){var ed=await epRes.json();available=Number(ed.meta&&ed.meta.count)||0}
   if(!total&&!available)return 0;
   cache[d.mal]={total:total,available:available,at:Date.now()};sv();
   if(total&&!d.e)d.e=total;
   if(!total&&available&&!d.ae)d.ae=available;
   refreshEpCount(d);return total||available;
  }catch(e){return 0}
 })();
 var result=await kitsuPending[d.mal];delete kitsuPending[d.mal];return result;
}
var jikanPending={};
async function jikanCount(d,force){
 if(!d.mal)return;
 var cache=S.jikanEpisodes=S.jikanEpisodes||{},saved=cache[d.mal];
 if(saved&&Date.now()-saved.at<30*864e5){
  if(!d.e&&saved.total>0)d.e=saved.total;
  if(force&&d.mal===21)console.info("[AniWatch] One Piece: AniList/Shikimori =",d.e||0,"; Jikan =",saved.total);
  refreshEpCount(d);return saved.total;
 }
 if(jikanPending[d.mal])return jikanPending[d.mal];
 jikanPending[d.mal]=(async()=>{
  try{
   var res=await fetch("https://api.jikan.moe/v4/anime/"+encodeURIComponent(d.mal));
   if(!res.ok)return 0;
   var json=await res.json(),total=Number(json.data&&json.data.episodes)||0;
   if(!total)return 0;
   cache[d.mal]={total:total,at:Date.now()};sv();
   if(!d.e)d.e=total;
   if(force&&d.mal===21)console.info("[AniWatch] One Piece: AniList/Shikimori =",d.e||0,"; Jikan =",total);
   refreshEpCount(d);return total;
  }catch(e){return 0}
 })();
 var result=await jikanPending[d.mal];delete jikanPending[d.mal];return result;
}
var relatedPending={};
var relationNames={SEQUEL:"Продолжение",PREQUEL:"Приквел",SIDE_STORY:"Побочная история",PARENT_STORY:"Основная история",ALTERNATIVE:"Альтернативная версия",ALTERNATIVE_SETTING:"Альтернативный сюжет",SPIN_OFF:"Спин-офф",SUMMARY:"Пересказ",FULL_STORY:"Полная версия",CHARACTER:"Связанные персонажи",OTHER:"Связанный тайтл",SOURCE:"Первоисточник",COMPILATION:"Сборник"};
var relatedFields="id idMal type format title{romaji english}genres seasonYear startDate{year}averageScore episodes statuscoverImage{extraLarge color} bannerImage";
function relatedCards(list){return list.map(x=>card(x)).join("")}
async function translateRelated(list){return enrichShikimori(list)}
async function loadRelated(d){
 var root=$("#related-anime");if(!root)return;
 var cached=S.relatedAnime=S.relatedAnime||{},saved=cached[d.id];
 if(saved&&saved.v===15&&Date.now()-saved.at<(Array.isArray(saved.similarAnime)&&saved.similarAnime.length?7*864e5:30*60*1000)){renderRelated(d,saved);return}
 if(relatedPending[d.id])return relatedPending[d.id];
 relatedPending[d.id]=(async()=>{
  var relatedFallbackLimited=false;
  try{
   var relations=[],creatorName="",creatorWorks=[],studioNames=[],staffPeople=[],similarAnime=[],franchiseRelated=[];
    // Shikimori is the primary source for franchise relations; AniList is fallback only.
    var shikiId=Number(d.shikiId)||((Number(d.id)>1000000000)?Number(d.id)-1000000000:0);
    if(!(shikiId>0)&&Number(d.mal)>0){
     try{var shikiMatches=await fetchAnimeByIds([Number(d.mal)]);shikiId=Number(shikiMatches&&shikiMatches[0]&&shikiMatches[0].id)||0}
     catch(resolveError){relatedFallbackLimited=true;console.warn("[AniWatch] Could not resolve Shikimori ID:",resolveError)}
    }
    if(shikiId>0){
     var rawRelated=[],cooldownKey="aw-related-cooldown-"+shikiId,cooldownUntil=0;
     try{cooldownUntil=Number(localStorage.getItem(cooldownKey))||0}catch(e){}
     if(cooldownUntil>Date.now()){
      relatedFallbackLimited=true;
      console.info("[AniWatch] Shikimori related lookup paused after rate limit");
     }else{
      try{rawRelated=await fetchAnimeRelated(shikiId)}
      catch(relatedError){
       relatedFallbackLimited=true;
       if(/HTTP 429/.test(String(relatedError&&relatedError.message||relatedError))){
        try{localStorage.setItem(cooldownKey,String(Date.now()+10*60*1000))}catch(e){}
        console.warn("[AniWatch] Shikimori rate limited related anime; AniList fallback will be used");
       }else console.warn("[AniWatch] Shikimori primary relations unavailable; AniList fallback will be used:",relatedError);
      }
     }
     var convertShiki=function(a){
      if(!a||!Number(a.id))return null;
      var id=1000000000+Number(a.id),genres=Array.isArray(a.genres)?a.genres.map(g=>esc(g.russian||g.name||"")).filter(Boolean):[];
      var status=a.status==="released"?"Завершён":a.status==="ongoing"?"Онгоинг":a.status==="anons"?"Скоро":"";
      return {id:id,shikiId:Number(a.id),source:"shikimori",mal:Number(a.myanimelist_id)||null,n:esc(a.russian||a.name||"Без названия"),o:esc(a.russian&&a.name&&a.russian!==a.name?a.name:""),g:genres.length?genres:["Аниме"],y:Number(String(a.aired_on||"").slice(0,4))||0,r:Number(a.score)||0,e:Number(a.episodes)||0,s:status,d:cleanDesc(a.description||""),c:["#7c3aed","#0f0f1a"],img:"",ban:"",kind:String(a.kind||"")};
     };
     var shikiSeen={};
     relations=(rawRelated||[]).map(x=>{var anime=convertShiki(x&&x.anime);if(!anime)return null;return {type:String(x.relation||"OTHER").toUpperCase().replace(/-/g,"_"),anime:anime}}).filter(x=>x&&!shikiSeen[x.anime.id]&&(shikiSeen[x.anime.id]=true));
     var shikiRelatedList=relations.map(x=>x.anime);
     shikiRelatedList.forEach(x=>{M[x.id]=x});
     if(shikiRelatedList.length)await xshikiPosters(shikiRelatedList);
    }else{
     relatedFallbackLimited=true;
     console.info("[AniWatch] No Shikimori ID available; AniList relations will be used");
    }
    // Fetch Shikimori similar titles immediately and let it run alongside AniList enrichment.
    var similarFetchFailed=false;
    var similarTask=(async()=>{
     if(!(shikiId>0)){similarFetchFailed=true;return}
     try{
      var similarRaw=await fetchAnimeSimilar(shikiId),similarSeen={};
      similarAnime=(similarRaw||[]).map(item=>{var a=item&&item.anime?item.anime:item;if(!a||!Number(a.id)||similarSeen[a.id])return null;similarSeen[a.id]=true;var genres=Array.isArray(a.genres)?a.genres.map(g=>esc(g.russian||g.name||"")).filter(Boolean):[];return {id:1000000000+Number(a.id),shikiId:Number(a.id),source:"shikimori",mal:Number(a.myanimelist_id)||null,n:esc(a.russian||a.name||"Без названия"),o:esc(a.russian&&a.name&&a.russian!==a.name?a.name:""),g:genres.length?genres:["Аниме"],y:Number(String(a.aired_on||"").slice(0,4))||0,r:Number(a.score)||0,e:Number(a.episodes)||0,s:a.status==="released"?"Завершён":a.status==="ongoing"?"Онгоинг":a.status==="anons"?"Скоро":"",d:cleanDesc(a.description||""),c:["#7c3aed","#0f0f1a"],img:"",ban:"",kind:String(a.kind||"")}}).filter(Boolean).slice(0,12);
     }catch(similarError){similarFetchFailed=true;console.warn("[AniWatch] Similar anime unavailable:",similarError)}
    })();
    try{
    var query,vars;
    if(d.source==="shikimori"){
     if(!(Number(d.mal)>0))throw new Error("Не удалось найти данные для этого аниме");
     query="query($mal:Int){Media(idMal:$mal,type:ANIME){relations{edges{relationType node{"+relatedFields+" relations{edges{relationType node{"+relatedFields+"}}}}}} studios(isMain:true){nodes{name}}}}";
     vars={mal:Number(d.mal)};
    }else{
     query="query($id:Int){Media(id:$id,type:ANIME){relations{edges{relationType node{"+relatedFields+" relations{edges{relationType node{"+relatedFields+"}}}}}} studios(isMain:true){nodes{name}}}}";
     vars={id:Number(d.aniId||d.id)};
    }
    var payload=await xgq(query,vars),media=payload&&payload.Media;
    if(!media)throw new Error("Не удалось получить данные об этом аниме");
    studioNames=(media.studios&&media.studios.nodes||[]).map(studio=>studio&&studio.name).filter(Boolean);
    var relSeen={},franchiseSeen={},franchiseRelated=[];
    var directEdges=(media.relations&&media.relations.edges||[]).filter(e=>e.node&&e.node.type==="ANIME"&&e.node.format!=="MUSIC"&&e.relationType!=="CHARACTER"&&e.node.id!==(d.aniId||d.id));
    if(!relations.length)relations=directEdges.map(e=>({type:e.relationType,anime:mp(e.node)})).filter(e=>{if(relSeen[e.anime.id])return false;relSeen[e.anime.id]=true;return true});
    // One bounded second hop from the already-fetched relation nodes; no per-title API requests.
    directEdges.forEach(edge=>{
     var via=mp(edge.node);
     (edge.node.relations&&edge.node.relations.edges||[]).forEach(nested=>{
      var node=nested&&nested.node;
      if(!node||node.type!=="ANIME"||node.format==="MUSIC"||node.id===(d.aniId||d.id)||relSeen[node.id]||franchiseSeen[node.id]||relations.some(r=>r.anime&&r.anime.mal&&Number(r.anime.mal)===Number(node.idMal)))return;
      franchiseSeen[node.id]=true;
      franchiseRelated.push({anime:mp(node),viaTitle:via.n,viaId:via.id,relation:String(nested.relationType||"OTHER")});
     });
    });
    franchiseRelated=franchiseRelated.slice(0,24);
    try{
     var staffQuery,staffVars;
     if(d.source==="shikimori"){staffQuery="query($mal:Int){Media(idMal:$mal,type:ANIME){staff(sort:RELEVANCE,perPage:10){edges{role node{id name{full} image{large} staffMedia(type:ANIME,sort:POPULARITY_DESC,perPage:25){nodes{"+relatedFields+"}}}}}}}";staffVars={mal:Number(d.mal)}}
     else{staffQuery="query($id:Int){Media(id:$id,type:ANIME){staff(sort:RELEVANCE,perPage:10){edges{role node{id name{full} image{large} staffMedia(type:ANIME,sort:POPULARITY_DESC,perPage:25){nodes{"+relatedFields+"}}}}}}}";staffVars={id:Number(d.aniId||d.id)}}
     var staffPayload=await xgq(staffQuery,staffVars),staffMedia=staffPayload&&staffPayload.Media;
     var staffEdges=(staffMedia&&staffMedia.staff&&staffMedia.staff.edges||[]).filter(e=>e.node&&e.node.name&&e.node.name.full);
     staffPeople=staffEdges.slice(0,8).map(e=>({name:e.node.name.full,role:e.role||"Участник команды",image:e.node.image&&e.node.image.large||""}));
     var creatorEdges=staffEdges.filter(e=>/original creator|原作|原案/i.test(e.role||""));
     creatorName=creatorEdges.length&&creatorEdges[0].node.name?creatorEdges[0].node.name.full:"";
     var creatorSeen={};
     creatorEdges.forEach(e=>(e.node.staffMedia&&e.node.staffMedia.nodes||[]).forEach(m=>{if(m&&m.type==="ANIME"&&m.format!=="MUSIC"&&m.id!==(d.aniId||d.id)&&!relSeen[m.id]&&!creatorSeen[m.id]){creatorSeen[m.id]=true;creatorWorks.push(mp(m))}}));
     creatorWorks=creatorWorks.slice(0,12);
    }catch(staffError){console.warn("[AniWatch] Creator works unavailable:",staffError)}
   }catch(anilistError){
    console.warn("[AniWatch] AniList fallback/enrichment unavailable; keeping Shikimori relations:",anilistError);
   }
   await similarTask;
   var all=relations.map(x=>x.anime).concat((franchiseRelated||[]).map(x=>x.anime),creatorWorks,similarAnime);await translateRelated(all);
   var data={v:15,relations:relations,franchiseRelated:franchiseRelated||[],similarAnime:similarAnime,creatorName:creatorName,creatorWorks:creatorWorks,studioNames:studioNames,staffPeople:staffPeople,at:Date.now()};
   // Positive similar results may live for a week; an empty successful response is retried after 30 minutes.
   if(!relatedFallbackLimited&&!similarFetchFailed){cached[d.id]=data;sv()}
   renderRelated(d,data);
  }catch(e){
   console.warn("[AniWatch] Related anime:",e);
   var el=$("#related-anime");if(el&&isRoute("title",d.id))el.innerHTML='<section class="shelf"><h2>Связанные релизы</h2><p class="related-state">Не удалось загрузить связи. Попробуйте обновить страницу.</p><p class="related-state"><small>Причина: '+esc(String(e&&e.message||e).slice(0,160))+'</small></p></section>';
  }finally{delete relatedPending[d.id]}
 })();
 return relatedPending[d.id];
}
function renderRelated(d,data){
 var root=$("#related-anime");if(!root||!isRoute("title",d.id))return;
 var rel=(data.relations||[]).filter(x=>x&&x.anime),franchiseRelated=(data.franchiseRelated||[]).filter(x=>x&&x.anime),creatorWorks=(data.creatorWorks||[]).filter(Boolean),similarAnime=(data.similarAnime||[]).filter(Boolean);
 rel.forEach(x=>{M[x.anime.id]=x.anime});franchiseRelated.forEach(x=>{M[x.anime.id]=x.anime});creatorWorks.forEach(x=>{M[x.id]=x});similarAnime.forEach(x=>{M[x.id]=x});
 var groups={};
 rel.forEach(x=>(groups[x.type]=groups[x.type]||[]).push(x.anime));
 // Build only the directly evidenced story chain. Do not infer canon or missing franchise entries.
 var orderTypes=["PREQUEL","PARENT_STORY","SEQUEL"];
 var isMovie=a=>/movie/.test(String(a&&a.kind||"").toLowerCase()),isExtra=a=>/^(ova|ona|special|tv_special)$/.test(String(a&&a.kind||"").toLowerCase());
 var orderItems=[];
 orderTypes.forEach(type=>(groups[type]||[]).filter(anime=>!isMovie(anime)&&!isExtra(anime)).slice().sort((a,b)=>(Number(a.y)||9999)-(Number(b.y)||9999)).forEach(anime=>orderItems.push({type:type,anime:anime})));
 var orderHtml=orderItems.length?'<section class="franchise-order"><div class="franchise-order-head"><div><h2>Порядок просмотра</h2><p>Показаны только прямые связи, найденные в источнике. Это не полный хронологический или канонический список франшизы.</p></div><span>По связям тайтлов</span></div><ol class="franchise-order-list">'+orderItems.filter(x=>x.type==="PREQUEL"||x.type==="PARENT_STORY").map(x=>'<li><span class="franchise-order-type">Приквел</span>'+card(x.anime)+'</li>').join("")+'<li class="is-current"><span class="franchise-order-type">Выбранное аниме</span>'+card(d)+'</li>'+orderItems.filter(x=>x.type==="SEQUEL").map(x=>'<li><span class="franchise-order-type">'+esc(relationNames[x.type]||"Продолжение")+'</span>'+card(x.anime)+'</li>').join("")+'</ol></section>':'';
 var categorized={films:[],extras:[],spinoffs:[],other:[]},categorySeen=new Set();
 var candidates=rel.filter(x=>!orderTypes.includes(x.type)||isMovie(x.anime)||isExtra(x.anime)).map(x=>({anime:x.anime,relation:x.type,via:""})).concat(franchiseRelated.map(x=>({anime:x.anime,relation:x.relation,via:x.viaTitle})));
 candidates.forEach(item=>{var anime=item.anime,key=String(anime.id);if(categorySeen.has(key))return;categorySeen.add(key);if(isMovie(anime))categorized.films.push(item);else if(isExtra(anime))categorized.extras.push(item);else if(item.relation==="SPIN_OFF"||item.relation==="SIDE_STORY")categorized.spinoffs.push(item);else categorized.other.push(item)});
 var renderCategory=(title,description,items)=>items.length?'<section class="shelf related-shelf franchise-category"><div class="shelf-head"><div><h2>'+title+'</h2><p class="shelf-sub">'+description+'</p></div></div><div class="row">'+relatedCards(items.slice(0,18).map(item=>item.anime))+'</div></section>':'';
 var franchiseSections=renderCategory("Фильмы франшизы","Полнометражные релизы, связанные с этой историей",categorized.films)+renderCategory("OVA и специальные выпуски","Дополнительные эпизоды и специальные релизы",categorized.extras)+renderCategory("Спин-оффы и побочные истории","Ответвления франшизы и отдельные сюжетные линии",categorized.spinoffs)+renderCategory("Другие релизы франшизы","Остальные связанные произведения, тип которых не удалось точнее определить",categorized.other);
 var creatorHtml=creatorWorks.length?'<section class="shelf related-shelf"><div class="shelf-head"><div><h2>Другие работы автора</h2><p class="shelf-sub">'+(data.creatorName?'Ещё аниме '+esc(data.creatorName):'Другие аниме того же автора')+'. Не связаны сюжетом — их объединяет автор.</p></div></div><div class="row">'+relatedCards(creatorWorks)+'</div></section>':"";
 const extra=$("#anime-extra-meta");
 if(extra){
  const studios=(data.studioNames||[]).filter(Boolean),staff=(data.staffPeople||[]).filter(person=>person&&person.name);
  const staffHtml=staff.length?'<div class="anime-staff-list">'+staff.slice(0,8).map(person=>'<div class="anime-staff-person">'+(person.image?'<img src="'+esc(person.image)+'" alt="" loading="lazy">':'<span class="anime-staff-avatar">'+esc(person.name.slice(0,1))+'</span>')+'<span><b>'+esc(person.name)+'</b><small>'+esc(person.role)+'</small></span></div>').join("")+'</div>':'';
  extra.innerHTML=(studios.length?'<div class="anime-meta-line"><span>Студия</span><b>'+studios.map(esc).join(", ")+'</b></div>':'')+(staffHtml?'<div class="anime-meta-staff"><span class="anime-meta-label">Создатели и команда</span>'+staffHtml+'</div>':'');
  extra.hidden=!studios.length&&!staffHtml;
 }
 var similarHtml=similarAnime.length?'<section class="shelf related-shelf similar-anime-shelf"><div class="shelf-head"><div><h2>Похожие аниме</h2><p class="shelf-sub">Другие произведения с похожей тематикой. Они не являются частью этой франшизы.</p></div></div><div class="row">'+relatedCards(similarAnime)+'</div></section>':'';
 root.innerHTML=orderHtml+franchiseSections+creatorHtml+similarHtml||'<section class="shelf related-shelf related-empty"><div class="shelf-head"><div><h2>Связанные релизы</h2><p class="shelf-sub">Продолжения, фильмы, дополнительные выпуски и похожие аниме</p></div></div><p class="related-state">Для этого тайтла пока не удалось найти подтверждённые связанные произведения. Это не означает, что продолжений или фильмов не существует — источник может не содержать этих связей.</p></section>';
 xshikiPosters(rel.map(x=>x.anime).concat(franchiseRelated.map(x=>x.anime),creatorWorks,similarAnime));
}
function refreshEpCount(d){
 var ef=$("#featured-count"),et=$("#title-count");
 if(ef&&ef.dataset.id==d.id)ef.textContent=epLabel(d);
 if(et&&et.dataset.id==d.id){et.textContent=epLabel(d);var el=$(".title-episodes .eps"),ec=$(".title-episodes .episode-count");if(el)el.innerHTML=eps(d,0,true);if(ec)ec.textContent=epTotal(d)>0?epTotal(d)+" серий":"Серии"}
}
async function ru(d){
 anilibriaCount(d);if(!d.mal)return;
 // Never request /animes/{MAL_ID} from Shikimori: that endpoint expects a Shikimori ID.
 // Keep AniList's title/description intact and enrich only episode counts using MAL-aware APIs.
 if(!d.e)await jikanCount(d,false);
 if(!d.e||!d.ae)await aniZipCount(d);
 if(!d.e||!d.ae||Number(d.mal)===21)await kitsuCount(d,false);
 refreshEpCount(d);
}

// Русские названия одним запросом к Shikimori (id там совпадают с MAL), кэш в localStorage
async function rn(){await enrichShikimori(D)}
async function boot(){
 S=await initializeLocalState(S,value=>{S=value});
 // Облачная сессия восстанавливается в фоне: она не должна блокировать первый экран.
 (async()=>{try{var auth=await initializeSupabaseAuth();AUTH_USER=auth.user;if(AUTH_USER){S=await restoreCloudState(S,AUTH_USER.id);await xhyd();myListCloudAt=Date.now();var feedback=await loadRecommendationFeedback(AUTH_USER.id);S.recommendationDismissed={...(S.recommendationDismissed||{}),...feedback};saveLocalState(S,M);if(activePage()==="home"){refreshContinueShelf();loadHomeRecommendations()}else if(activePage()==="mylist")V.mylist();else if(activePage()==="favorites")V.favorites();else if(activePage()==="profile")V.profile();else if(activePage()==="calendar")V.calendar()}}catch(e){console.warn("[AniWatch] Supabase session restore failed:",e)}})();
 app.innerHTML='<p class="empty">Загрузка каталога…</p>';
 var c;try{c=JSON.parse(localStorage.getItem("awc")||"null")}catch(e){}
 if(!c||c.v!==2||!c.a||c.a.length>30||Date.now()-c.t>216e5){
  try{var ctl=new AbortController(),tm=setTimeout(()=>ctl.abort(),6000),r=await fetch("https://graphql.anilist.co",{method:"POST",signal:ctl.signal,headers:{"Content-Type":"application/json",Accept:"application/json"},body:JSON.stringify({query:Q})});clearTimeout(tm);var j=await r.json();c={v:2,t:Date.now(),a:j.data.Page.media.map(mp)};try{localStorage.setItem("awc",JSON.stringify(c))}catch(e){}}catch(e){}
 }
 if(c&&c.a&&c.a.length)D=c.a;else D=[];
 idx();hydrateStash();initRouteFilters();
 var enrichment=rn(),hydration=xhyd();
 await ensureRouteItem();
 if(activePage()==="home"){
  try{await loadHomeCollections()}catch(e){console.warn("[AniWatch] Home collections unavailable:",e)}
  draw();
  Promise.allSettled([enrichment,hydration]).then(()=>{if(activePage()==="home"){refreshContinueShelf();loadHomeRecommendations()}});
 }else{await Promise.allSettled([enrichment,hydration]);draw()}
}

// ---- v2: каталог по всей базе AniList и трейлеры ----
var xMF="id idMal format title{romaji english}genres seasonYear startDate{year month}averageScore episodes status coverImage{extraLarge color}bannerImage",
homeCollections=null;
function normalizeMatchTitle(value){
 return String(value||"").toLocaleLowerCase("ru").normalize("NFKC").replace(/[ё]/g,"е").replace(/[\\s\\p{P}\\p{S}]+/gu,"").trim();
}
function aniLibriaPosterUrl(release){
 var poster=release&&release.poster||{},optimized=poster.optimized||{};
 var candidates=[optimized.src,poster.src,optimized.preview,poster.preview,optimized.thumbnail,poster.thumbnail];
 for(var value of candidates){
  if(typeof value!=="string"||!value.trim())continue;
  try{return new URL(value.trim(),"https://anilibria.top").href}catch(e){}
 }
 return "";
}
function aniLibriaNames(release){
 var name=release&&release.name||{};
 return [name.main,name.english,...String(name.alternative||"").split(",")].map(value=>String(value||"").trim()).filter(Boolean);
}
function matchAniLibriaRelease(release,candidates){
 var names=new Set(aniLibriaNames(release).map(normalizeMatchTitle).filter(Boolean));
 if(!names.size)return null;
 var year=Number(release&&release.year)||0;
 var matches=(candidates||[]).filter(item=>{
  var itemNames=[item&&item.russian,item&&item.name].map(normalizeMatchTitle).filter(Boolean);
  if(!itemNames.some(name=>names.has(name)))return false;
  var itemYear=Number(String(item&&item.aired_on||"").slice(0,4))||0;
  // A one-year tolerance can map a sequel to the previous season when both share a Russian title.
  if(year&&itemYear)return year===itemYear;
  return true;
 });
 if(year)return matches[0]||null;
 // Without a release year, never guess between seasons sharing the same title.
 var unique=new Map(matches.filter(item=>Number(item&&item.id)>0).map(item=>[Number(item.id),item]));
 return unique.size===1?[...unique.values()][0]:null;
}
async function loadHomeCollections(){
 var source=null,cache=null;
 try{cache=JSON.parse(localStorage.getItem("aw-home-anilibria-shiki-v3")||"null")}catch(e){}
 if(cache&&cache.data&&Date.now()-Number(cache.at)<20*60*1000)source=cache.data;
 if(!source){
  try{
   source=await fetchAniLibriaHomeCollections();
   try{localStorage.setItem("aw-home-anilibria-shiki-v3",JSON.stringify({at:Date.now(),data:source}))}catch(e){}
  }catch(error){
   console.warn("[AniWatch] AniLibria home source unavailable; using Shikimori fallback:",error);
   source={popular:[],recommended:[],ongoing:[],recent:[]};
  }
 }
 var lists=["recent","ongoing","popular","recommended"],releaseIds=new Set();
 lists.forEach(key=>(source[key]||[]).forEach(release=>{
  var id=Number(release&&release.shikimori&&release.shikimori.id);
  if(Number.isInteger(id)&&id>0)releaseIds.add(id);
 }));
 var shikiById=new Map();
 var idList=[...releaseIds];
 for(var i=0;i<idList.length;i+=50){
  try{
   var batch=await fetchAnimeByIds(idList.slice(i,i+50));
   batch.forEach(item=>shikiById.set(Number(item.id),item));
  }catch(error){console.warn("[AniWatch] Shikimori ID mapping batch failed:",error)}
 }
 var seenIds=new Set(),seenMalIds=new Set(),searchBudget=12;
 Object.keys(S.hist||{}).forEach(id=>{
  var saved=M[id]||(S.shikiAnime&&S.shikiAnime[id]),numeric=Number(id);
  var shikiId=Number(saved&&saved.shikiId)||(numeric>=1000000000?numeric-1000000000:0);
  var mal=Number(saved&&saved.mal)||0;
  if(shikiId>0)seenIds.add(shikiId);
  if(mal>0)seenMalIds.add(mal);
 });
 async function resolveRelease(release){
  var shikiId=Number(release&&release.shikimori&&release.shikimori.id);
  var item=shikiId?shikiById.get(shikiId):null;
  if(!item){
   var names=aniLibriaNames(release);
   for(var name of names){
    if(searchBudget<=0)break;
    if(normalizeMatchTitle(name).length<3)continue;
    searchBudget--;
    try{
     var matches=await fetchCatalogPage({query:name,page:1,limit:20,order:"popularity"});
     item=matchAniLibriaRelease(release,matches);
     if(item)break;
    }catch(error){console.warn("[AniWatch] Shikimori title mapping failed:",error)}
   }
  }
  if(!item)return null;
  var mapped=shikiToItem(item);
  if(!mapped||!Number(mapped.shikiId)||seenIds.has(Number(mapped.shikiId))||(Number(mapped.mal)>0&&seenMalIds.has(Number(mapped.mal))))return null;
  // Keep the AniLibria release ID and known episode total. The hero can use these
  // directly instead of searching AniLibria by title again.
  mapped.aniLibriaReleaseId=Number(release&&release.id)||0;
  var releaseEpisodeTotal=Number(release&&release.episodes_total)||0;
  if(releaseEpisodeTotal>0)mapped.e=releaseEpisodeTotal;
  // AniLibria supplies the primary poster; retain Shikimori artwork as an on-error fallback.
  var aniPoster=aniLibriaPosterUrl(release);
  if(aniPoster){mapped.posterFallback=shikiImageUrl(mapped.img);mapped.img=aniPoster;}
  seenIds.add(Number(mapped.shikiId));
  if(Number(mapped.mal)>0)seenMalIds.add(Number(mapped.mal));
  return mapped;
 }
 async function resolveShelf(key){
  var output=[];
  for(var release of (source[key]||[])){
   if(output.length>=15)break;
   var mapped=await resolveRelease(release);
   if(mapped)output.push(mapped);
  }
  return output;
 }
 var mappedLists={};
 for(var key of lists)mappedLists[key]=await resolveShelf(key);
 async function fillShelf(key,options){
  var output=mappedLists[key];
  if(output.length>=15)return;
  try{
   var candidates=await fetchCatalogPage(Object.assign({page:1,limit:50},options));
   for(var candidate of candidates){
    if(output.length>=15)break;
    var id=Number(candidate&&candidate.id),mal=Number(candidate&&candidate.myanimelist_id)||0;
    if(!id||seenIds.has(id)||(mal>0&&seenMalIds.has(mal)))continue;
    seenIds.add(id);
    if(mal>0)seenMalIds.add(mal);
    output.push(shikiToItem(candidate));
   }
  }catch(error){console.warn("[AniWatch] Shikimori home fallback failed ("+key+"):",error)}
 }
 await fillShelf("recent",{order:"aired_on",status:"released"});
 await fillShelf("ongoing",{order:"popularity",status:"ongoing"});
 await fillShelf("popular",{order:"popularity"});
 await fillShelf("recommended",{order:"ranked"});
 homeCollections=mappedLists;
 var allHome=homeCollections.recent.concat(homeCollections.ongoing,homeCollections.popular,homeCollections.recommended);
 allHome.forEach(d=>{M[d.id]=d;S.shikiAnime=S.shikiAnime||{};S.shikiAnime[d.id]=d});
 xshikiPosters(allHome).catch(error=>console.warn("[AniWatch] Shikimori poster enrichment failed:",error));
 if(homeCollections.popular.length)H=homeCollections.popular;
 console.info("[AniWatch] Home shelves resolved:",lists.map(key=>key+":"+homeCollections[key].length).join(", "),"; title searches left:",searchBudget);
 return homeCollections;
}
var xCQ="query($p:Int,$s:String,$g:[String],$y:String,$season:MediaSeason,$st:MediaStatus,$f:[MediaFormat],$o:[MediaSort]){Page(page:$p,perPage:24){pageInfo{hasNextPage total}media(type:ANIME,isAdult:false,search:$s,genre_in:$g,startDate_like:$y,season:$season,status:$st,format_in:$f,sort:$o){"+xMF+"}}}",
xCQ_SAFE="query($p:Int,$s:String,$g:[String],$y:String,$season:MediaSeason,$st:MediaStatus,$f:[MediaFormat],$o:[MediaSort]){Page(page:$p,perPage:24){pageInfo{hasNextPage total}media(type:ANIME,isAdult:false,search:$s,genre_in:$g,startDate_like:$y,season:$season,status:$st,format_in:$f,sort:$o){id idMal format title{romaji english}genres seasonYear startDate{year month}averageScore episodes status coverImage{extraLarge color}}}}",
xCF={g:"",y:"",season:"",st:"",f:"",o:"POPULARITY_DESC",q:"",minScore:"",p:1,more:true,busy:false,k:0},xSearchRequest=0,xIO=null,xGenrePromise=null,xGenreOptions=null;
var xGL=["Action","Adventure","Comedy","Drama","Fantasy","Horror","Mahou Shoujo","Mecha","Music","Mystery","Psychological","Romance","Sci-Fi","Slice of Life","Sports","Supernatural","Thriller"],
xSO=[["POPULARITY_DESC","Популярные"],["SCORE_DESC","По рейтингу"],["START_DATE_DESC","Сначала новые"],["TITLE_ROMAJI","По названию"]],
xST=[["RELEASING","Онгоинг"],["FINISHED","Завершён"],["NOT_YET_RELEASED","Скоро"]],
xFM=[["TV","Сериал"],["MOVIE","Фильм"],["OVA","OVA"],["ONA","ONA"],["SPECIAL","Спешл"]];
GR["Mahou Shoujo"]=GR["Mahou Shoujo"]||"Махо-сёдзё";
// русские названия для произвольного списка (пачками по 50, кэш awr2)
async function xrn(L){return enrichShikimori(L)}
// избранное/история/списки, найденные через каталог, подгружаем по id после перезагрузки
async function xhyd(){
 var ids=new Set([].concat(S.fav||[],Object.keys(S.hist||{}),Object.keys(S.rate||{}),Object.keys(S.watchedEpisodes||{})).map(Number).filter(i=>Number.isSafeInteger(i)&&i>0)),w=S.watchlist;
 if(Array.isArray(w))w.forEach(item=>{var id=Number(item&&(item.id??item.anime_id??item.animeId));if(Number.isSafeInteger(id)&&id>0)ids.add(id)});
 else if(w&&typeof w==="object")Object.keys(w).forEach(k=>{var id=Number(k);if(Number.isSafeInteger(id)&&id>0)ids.add(id)});
 var saved=S.shikiAnime||{};ids.forEach(i=>{if(!M[i]&&saved[i])M[i]=saved[i]});
 var need=[...ids].filter(i=>i<1000000000&&!M[i]);
 for(var offset=0;offset<need.length;offset+=50){
  var batch=need.slice(offset,offset+50);
  try{var L=(await xgq("query($i:[Int]){Page(perPage:50){media(id_in:$i,type:ANIME){"+xMF+"}}}",{i:batch})).Page.media.map(x=>M[x.id]=mp(x));await xrn(L)}
  catch(e){console.warn("[AniWatch] Could not hydrate part of the saved list:",e);break}
 }
 var shikiNeed=[...ids].filter(i=>i>=1000000000&&!M[i]).map(i=>i-1000000000);
 for(var offset=0;offset<shikiNeed.length;offset+=50){
  try{
   var records=await fetchAnimeByIds(shikiNeed.slice(offset,offset+50));
   records.forEach(item=>{var d=shikiToItem(item);M[d.id]=d;S.shikiAnime=S.shikiAnime||{};S.shikiAnime[d.id]=d});
  }catch(e){console.warn("[AniWatch] Could not hydrate Shikimori items in the saved list:",e);break}
 }
}
// Shikimori is the single source for poster artwork. Keep image URLs transient.
async function xshikiPosters(L,{resolveMalIds=false}={}){
 L=(L||[]).filter(Boolean);
 var needsLookup=L.filter(d=>Number(d.mal)>0&&!d.shikiId&&!shikiImageUrl(d.img));
 if(needsLookup.length)await enrichShikimori(needsLookup);
 var findItem=id=>(L||[]).find(x=>Number(x.shikiId||((Number(x.id)||0)>=1000000000?Number(x.id)-1000000000:0))===Number(id));
 var ids=[...new Set((L||[]).map(d=>Number(d.shikiId||((Number(d.id)||0)>=1000000000?Number(d.id)-1000000000:0))).filter(id=>{
  if(!Number.isInteger(id)||id<=0)return false;
  var item=findItem(id);
  return !dHasImage(L,id)||(resolveMalIds&&item&&!Number(item.mal));
 }))];
 try{
  for(var i=0;i<ids.length;i+=50){
   var batchIds=ids.slice(i,i+50),posters=await fetchAnimePostersByIds(batchIds);
   posters.forEach(a=>{
    var d=findItem(a.id);if(!d)return;
    var poster=a.poster||{},path=shikiImageUrl(poster.originalUrl||poster.mainUrl);
    if(path)d.img=path;
    if(Number(a.malId)>0)d.mal=Number(a.malId);
    M[d.id]=d;if(d.source==="shikimori"){S.shikiAnime=S.shikiAnime||{};S.shikiAnime[d.id]=d}
   });
  }
 }catch(e){console.warn("[AniWatch] Shikimori GraphQL poster lookup failed:",e)}
 // REST is a fallback only; never treat Shikimori's missing_original image as artwork.
 var restIds=ids.filter(id=>{var d=findItem(id);return d&&!shikiImageUrl(d.img)});
 for(var j=0;j<restIds.length;j+=50){
  try{
   var batch=await fetchAnimeByIds(restIds.slice(j,j+50));
   batch.forEach(a=>{
    var d=findItem(a.id);if(!d)return;
    var image=a.image||{},path=shikiImageUrl(image.original||image.preview||image.x96);
    if(path)d.img=path;
    if(Number(a.malId)>0)d.mal=Number(a.malId);
    M[d.id]=d;if(d.source==="shikimori"){S.shikiAnime=S.shikiAnime||{};S.shikiAnime[d.id]=d}
   });
  }catch(e){console.warn("[AniWatch] Shikimori REST poster fallback failed:",e);break}
 }
 document.querySelectorAll("[data-anime-id]").forEach(el=>{
  var d=M[Number(el.dataset.animeId)];if(!d||!shikiImageUrl(d.img))return;
  var poster=el.classList.contains("card")?el.querySelector(".poster"):el.classList.contains("collection-anime-poster")?el:el.classList.contains("poster")?el:null;
  if(!poster)return;
  if(el.classList.contains("collection-anime-poster")){var img=document.createElement("img");img.src=d.img;img.alt="";img.loading="lazy";img.fetchPriority="low";poster.replaceChildren(img)}
  else{poster.style.background=bg(d);var img=poster.querySelector(".poster-image");if(!img){img=document.createElement("img");img.className="poster-image";img.alt="";img.loading="lazy";img.fetchPriority="low";img.decoding="async";poster.prepend(img)}if(img.src!==d.img)img.src=d.img;img.onerror=function(){var fallback=d.posterFallback;if(fallback&&this.dataset.posterFallback!=="used"){this.dataset.posterFallback="used";this.src=fallback;return}this.removeAttribute("src");this.style.display="none"};var letter=poster.querySelector("i");if(letter)letter.remove()}
 });
 var current=M[routeArgs()[0]],player=$(".player");if(current&&player&&shikiImageUrl(current.img))player.style.background=bn(current);
 var hero=$("#hw .hero-editorial"),featuredItem=H[featuredIndex%H.length];if(hero&&featuredItem&&shikiImageUrl(featuredItem.img)){hero.style.setProperty("--hero-poster","url("+JSON.stringify(featuredItem.img)+")");var hp=hero.querySelector(".hero-poster");if(hp)hp.style.background=bg(featuredItem)}
 sv();
}
function dHasImage(list,id){
 return (list||[]).some(d=>Number(d.shikiId||((Number(d.id)||0)>=1000000000?Number(d.id)-1000000000:0))===id&&!!shikiImageUrl(d.img));
}
V.catalog=()=>{
 clearTimeout(xCF.h);xSearchRequest++;xCF.p=1;xCF.more=true;xCF.busy=false;xCF.k++;
 renderCatalogPage({
  app,filters:xCF,escapeHtml:esc,genreOptions:xGenreOptions||[],genreLabels:{},
  yearOptions:Array.from({length:new Date().getFullYear()-1970+1},(_,i)=>[String(new Date().getFullYear()-i),String(new Date().getFullYear()-i)]),
  seasonOptions:[["winter","Зима"],["spring","Весна"],["summer","Лето"],["fall","Осень"]],
  statusOptions:[["RELEASING","Онгоинг"],["FINISHED","Завершён"],["NOT_YET_RELEASED","Скоро"]],
  formatOptions:[["TV","Сериал"],["MOVIE","Фильм"],["OVA","OVA"],["ONA","ONA"],["SPECIAL","Спешл"]],
  sortOptions:[["POPULARITY_DESC","Популярные"],["SCORE_DESC","По рейтингу"],["START_DATE_DESC","Сначала новые"],["TITLE_ROMAJI","По названию"]],
  ratingOptions:[["6","6.0+"],["7","7.0+"],["8","8.0+"],["9","9.0+"]]
 });
 xCF.q=F.q||xCF.q||"";xCF.g=F.g||xCF.g||"";F.q=xCF.q;F.g=xCF.g;
 var csInput=$("#cs"),genreSelect=$("#cf-g");if(csInput)csInput.value=xCF.q;
 var hqi=$("#q");if(hqi)hqi.value=xCF.q;if(genreSelect)genreSelect.value=xCF.g;
 if(!xGenrePromise)xGenrePromise=fetchShikimoriGenreList().then(list=>{var seenIds=new Set(),seenNames=new Set();xGenreOptions=list.filter(g=>g&&g.kind==="genre"&&String(g.entry_type||"").toLowerCase()==="anime").map(g=>({id:String(g.id||"").trim(),ru:String(g.russian||"").trim(),name:String(g.name||"").trim()})).filter(g=>{var id=g.id,keys=[g.ru,g.name].filter(Boolean).map(v=>v.normalize("NFKC").toLocaleLowerCase("ru").replace(/[ё]/g,"е").replace(/[\s\p{P}\p{S}]+/gu,""));if(!id||seenIds.has(id)||!keys.length||keys.some(k=>seenNames.has(k)))return false;seenIds.add(id);keys.forEach(k=>seenNames.add(k));return true}).map(g=>[g.id,g.ru||g.name]).sort((a,b)=>a[1].localeCompare(b[1],"ru"));return xGenreOptions}).catch(e=>{console.warn("[AniWatch] Genre list unavailable:",e);return null});
 var routeKey=xCF.k;
 xGenrePromise.then(options=>{if(routeKey!==xCF.k||activePage()!=="catalog")return;if(options&&options.length){var select=$("#cf-g"),value=xCF.g;if(value&&!/^[0-9]+$/.test(value)){var legacy=options.find(g=>String(g[1]).toLowerCase()===String(value).toLowerCase());value=legacy?legacy[0]:"";xCF.g=value}select.innerHTML="<option value=\"\">Все жанры</option>"+options.map(g=>"<option value=\""+esc(g[0])+"\">"+esc(g[1])+"</option>").join("");select.value=value}xcq(true)});
};
rc=()=>{var s=$("#cs");xCF.q=s?s.value.trim():(F.q||"");F.q=xCF.q;if(s&&s!==document.activeElement)s.value=xCF.q;clearTimeout(xCF.h);xCF.h=setTimeout(()=>xcq(true),450)};
async function xcq(reset){
 if(reset){xSearchRequest++;xCF.p=1;xCF.more=true;xCF.busy=false;var c0=$("#cr");if(c0)c0.innerHTML="";syncCatalogUrl()}
 if(!xCF.more||xCF.busy||!$("#cr"))return;
 var requestId=++xSearchRequest;xCF.busy=true;var k=++xCF.k,box=$("#more");if(box)box.textContent="Загрузка…";
 try{
  var q=xCF.q.trim(),sourcePage=xCF.p;
  var key="aw-shikimori-catalog-v4:"+JSON.stringify([q,sourcePage,xCF.g,xCF.y,xCF.season,xCF.st,xCF.f,xCF.o,xCF.minScore]);
  var cached=null,raw=null;
  try{cached=JSON.parse(localStorage.getItem(key)||"null")}catch(e){}
  if(cached&&Date.now()-cached.at<10*60*1000)raw=cached.data;
  if(!raw){
   var order=xCF.o==="SCORE_DESC"?"ranked":xCF.o==="START_DATE_DESC"?"aired_on":xCF.o==="TITLE_ROMAJI"?"name":"popularity";
   raw=await fetchCatalogPage({query:q,page:sourcePage,order,format:xCF.f,status:xCF.st,genre:xCF.g});
   try{localStorage.setItem(key,JSON.stringify({at:Date.now(),data:raw}))}catch(e){}
  }
  if(requestId!==xSearchRequest||k!==xCF.k||activePage()!=="catalog")return;
  var L=(Array.isArray(raw)?raw:[]).map(shikiToItem);

  if(xCF.y)L=L.filter(d=>String(d.y)===String(xCF.y));
  if(xCF.season){
   var months={winter:[12,1,2],spring:[3,4,5],summer:[6,7,8],fall:[9,10,11]}[xCF.season]||[];
   L=L.filter(d=>months.includes(d.mth));
  }
  if(xCF.minScore)L=L.filter(d=>Number(d.r||0)>=Number(xCF.minScore));
  L.forEach(d=>{M[d.id]=d;S.shikiAnime=S.shikiAnime||{};S.shikiAnime[d.id]=d});
  var cr=$("#cr");if(!cr)return;
  cr.insertAdjacentHTML("beforeend",L.map(d=>card(d)).join(""));
  xshikiPosters(L);
  xCF.p=sourcePage+1;xCF.more=Array.isArray(raw)&&raw.length===50;xCF.busy=false;
  $("#cc").textContent=q?"Результаты поиска":"Каталог";
  if(box)box.textContent=xCF.more?"Загрузить ещё":"Это все результаты";
  if(!cr.children.length)$("#cc").textContent=q?"Ничего не найдено":"В каталоге пока нет результатов";
  sv();
 }catch(e){
  console.error("[AniWatch] Shikimori catalog:",e);
  if(requestId===xSearchRequest&&k===xCF.k){xCF.busy=false;if(box)box.textContent="Ошибка загрузки. Нажмите, чтобы повторить";toast("Не удалось загрузить каталог. Попробуй позже.")}
 }
}
async function xrandom(){
 renderRandomLoading(app);
 try{
  var a=await fetchRandomAnime();
  var id=1000000000+Number(a.id),kind=String(a.kind||"").toLowerCase(),status=a.status==="released"?"Завершён":a.status==="ongoing"?"Онгоинг":a.status==="anons"?"Скоро":"";
  var genres=Array.isArray(a.genres)?a.genres.map(g=>esc(g.russian||g.name||"")).filter(Boolean):[];
  var d={id:id,shikiId:Number(a.id),source:"shikimori",mal:Number(a.myanimelist_id)||null,n:esc(a.russian||a.name||"Без названия"),o:esc(a.russian&&a.name&&a.russian!==a.name?a.name:""),g:genres.length?genres:["Аниме"],y:Number(String(a.aired_on||"").slice(0,4))||0,r:Number(a.score)||0,e:Number(a.episodes)||0,s:status,d:cleanDesc(a.description||""),c:["#7c3aed","#0f0f1a"],img:"",ban:"",kind:kind};
  M[id]=d;S.shikiAnime=S.shikiAnime||{};S.shikiAnime[id]=d;sv();
  xshikiPosters([d]);
  if(activePage()==="random"){stashItems([id]);location.replace(titleUrl(id))}
 }catch(e){
  console.error("[AniWatch] Random anime:",e);
  renderRandomError(app);
  toast("Не удалось выбрать случайное аниме");
 }
}
V.random=()=>{xrandom()};
listen(document,"scroll",()=>{if($("#more")&&xCF.more&&!xCF.busy&&window.innerHeight+window.scrollY>=document.documentElement.scrollHeight-900)xcq()},{passive:true});
listen(document,"click",e=>{if(e.target.closest("[data-cf-reset]")){F.q="";F.g="";xCF.g="";xCF.y="";xCF.st="";xCF.f="";xCF.o="POPULARITY_DESC";xCF.q="";xCF.minScore="";V.catalog();return}if(e.target.closest("[data-xr]"))xcq();});
// Баннеры главной, страниц тайтлов и плеера вынесены в отдельный модуль.
var bannerManager=createBannerManager({
 query:xgq,
 getAnimeMap:()=>M,
 getState:()=>S,
 getFeatured:()=>H,
 getFeaturedIndex:()=>featuredIndex,
 getPlayer:()=>P,
 isTitleRoute:id=>isRoute("title",id),
 background:bn,
 refreshFeatured:showFeatured,
 save:sv
});
var xvt=V.title;V.title=p=>{xvt(p);bannerManager.load(M[+p[0]])};
var xvw=V.watch;V.watch=p=>{xvw(p);bannerManager.load(M[+p[0]])};

function activePage(){return getActivePage()}
function hd(){updateNavigation(S)}
// ---- страницы: данные между переходами, адреса, фильтры ----
function htmlText(s){var t=document.createElement("textarea");t.innerHTML=String(s||"");return t.value}
function readAutoplay(){try{var v=sessionStorage.getItem("aw.ap")==="1";sessionStorage.removeItem("aw.ap");return v}catch(e){return false}}
// Каждая страница загружается заново, поэтому карточки, которые видел пользователь, передаём следующей странице через sessionStorage.
function stashItems(extra){
 try{
  var ids={};
  (extra||[]).forEach(i=>{ids[i]=1});
  var cur=routeArgs()[0];if(cur)ids[cur]=1;
  document.querySelectorAll("[data-anime-id]").forEach(c=>{ids[c.dataset.animeId]=1});
  document.querySelectorAll('a[href*="id="]').forEach(a=>{var m=/[?&]id=(\d+)/.exec(a.getAttribute("href")||"");if(m)ids[m[1]]=1});
  var out={},n=0;
  Object.keys(ids).forEach(i=>{if(n<500&&M[i]&&M[i].n){out[i]=M[i];n++}});
  sessionStorage.setItem("aw.items",JSON.stringify(out));
 }catch(e){try{sessionStorage.removeItem("aw.items")}catch(e2){}}
}
function hydrateStash(){
 try{var o=JSON.parse(sessionStorage.getItem("aw.items")||"{}");Object.keys(o).forEach(i=>{if(!M[i])M[i]=o[i]})}catch(e){}
}
function shikiToItem(a){
 var st=a.status==="released"?"Завершён":a.status==="ongoing"?"Онгоинг":a.status==="anons"?"Скоро":"";
 var genres=Array.isArray(a.genres)?a.genres.map(g=>esc(g.russian||g.name||"")).filter(Boolean):[];
 var image=a.image||{},path=image.original||image.preview||image.x96||"",mal=Number(a.myanimelist_id)||null;
 // Reuse the real AniList ID and banner when this MAL ID exists in the initial AniList result.
 var aniMatch=mal&&Array.isArray(D)?D.find(item=>Number(item.mal)===mal):null;
 var aniId=Number(aniMatch&&aniMatch.id)||null,banner=aniMatch&&typeof aniMatch.ban==="string"?aniMatch.ban:"";
 return{id:1000000000+Number(a.id),shikiId:Number(a.id),aniId:aniId,source:"shikimori",mal:mal,n:esc(a.russian||a.name||"Без названия"),o:esc(a.russian&&a.name&&a.russian!==a.name?a.name:""),g:genres.length?genres:["Аниме"],y:Number(String(a.aired_on||"").slice(0,4))||0,mth:Number(String(a.aired_on||"").slice(5,7))||0,r:Number(a.score)||0,e:Number(a.episodes)||0,s:st,d:cleanDesc(a.description||""),c:["#7c3aed","#0f0f1a"],img:shikiImageUrl(path),ban:banner,kind:String(a.kind||"").toLowerCase()}
}
// Страница тайтла/плеера открыта по прямой ссылке — подгружаем тайтл по id, если его нет в памяти.
async function ensureRouteItem(){
 var page=activePage();if(page!=="title"&&page!=="watch")return;
 var id=routeArgs()[0];if(!id||M[id])return;
 try{
  if(id>=1000000000){
   var d=shikiToItem(await fetchAnimeById(id-1000000000));
   M[d.id]=d;S.shikiAnime=S.shikiAnime||{};await xshikiPosters([d]);
  }else{
   var L=(await xgq("query($i:[Int]){Page(perPage:1){media(id_in:$i,type:ANIME){"+xMF+"}}}",{i:[id]})).Page.media.map(x=>M[x.id]=mp(x));await xrn(L)
  }
 }catch(e){console.warn("[AniWatch] Title lookup:",e)}
}
function renderMissing(){
 document.title="Тайтл не найден — AniWatch";
 app.innerHTML='<section class="offline-state"><div class="eyebrow">404</div><h1>Тайтл не найден</h1><p>Не удалось загрузить это аниме. Ссылка могла устареть или возникла ошибка соединения.</p><a class="btn" href="'+pageUrl("catalog")+'">Открыть каталог</a> <button class="btn ghost" type="button" data-a="reload">Повторить</button></section>'
}
var URL_FILTERS={y:"y",season:"season",status:"st",format:"f",sort:"o",score:"minScore"};
function initRouteFilters(){
 if(activePage()!=="catalog")return;
 var p=new URLSearchParams(location.search);
 F.q=(p.get("q")||"").trim();F.g=p.get("g")||"";
 Object.keys(URL_FILTERS).forEach(k=>{var v=p.get(k);if(v)xCF[URL_FILTERS[k]]=v});
}
function syncCatalogUrl(){
 if(activePage()!=="catalog"||!window.history||!history.replaceState)return;
 var o={q:xCF.q,g:xCF.g,y:xCF.y,season:xCF.season,status:xCF.st,format:xCF.f,sort:xCF.o==="POPULARITY_DESC"?"":xCF.o,score:xCF.minScore};
 try{history.replaceState(null,"",pageUrl("catalog",o))}catch(e){}
}
function draw(){renderRoute(V,T,()=>{P=null;if(INLINE_STREAM_PLAYER){INLINE_STREAM_PLAYER.destroy();INLINE_STREAM_PLAYER=null}},S);var visible=[];document.querySelectorAll("[data-anime-id]").forEach(el=>{var d=M[Number(el.dataset.animeId)];if(d)visible.push(d)});if(activePage()==="title"||activePage()==="watch"){var current=M[routeArgs()[0]];if(current)visible.push(current)}if(visible.length)xshikiPosters([...new Map(visible.map(d=>[d.id,d])).values()])}
function msg(a,t){var m=$("#ms");if(!m)return;var d=document.createElement("div"),e=document.createElement("em");e.textContent=a;d.append(e,document.createTextNode(String(t||"")));m.append(d);m.scrollTop=1e5}

var heroTouch=null;listen(document,"touchstart",e=>{var h=e.target.closest("#hw .hero-editorial");if(!h||e.touches.length!==1)return;heroTouch={x:e.touches[0].clientX,y:e.touches[0].clientY}},{passive:true});listen(document,"touchend",e=>{if(!heroTouch)return;var p=heroTouch;heroTouch=null;if(!e.changedTouches.length||H.length<2)return;var dx=e.changedTouches[0].clientX-p.x,dy=e.changedTouches[0].clientY-p.y;if(Math.abs(dx)>48&&Math.abs(dx)>Math.abs(dy)*1.25){featuredIndex=(featuredIndex+(dx<0?1:-1)+H.length)%H.length;showFeatured()}},{passive:true});
listen(document,"click",e=>{var t=e.target.closest("[data-a]");if(!t)return;var a=t.dataset.a,i=+t.dataset.i,v=t.dataset.v;
 if(a==="profile-entry"){e.preventDefault();if(AUTH_USER)location.href=PAGES.profile;else openAuthModal()}
 else if(a==="auth-close"){var authModal=document.getElementById("auth-modal");if(authModal)closeDialog(authModal)}
 else if(a==="recommendation-genre"){e.preventDefault();e.stopPropagation();S.recommendationGenres=Array.isArray(S.recommendationGenres)?S.recommendationGenres.slice():[];var genreName=String(v||"");var genreIndex=S.recommendationGenres.indexOf(genreName);if(genreIndex>=0)S.recommendationGenres.splice(genreIndex,1);else if(S.recommendationGenres.length<3)S.recommendationGenres.push(genreName);else{toast("Можно выбрать не больше трёх жанров");return}sv();renderRecommendationStarter($("#recommendation-cards"),S.recommendationGenres)}
 else if(a==="recommendation-start"){e.preventDefault();e.stopPropagation();if(!(S.recommendationGenres||[]).length){toast("Выбери хотя бы один жанр");return}loadHomeRecommendations()}
 else if(a==="recommendation-dismiss"){e.preventDefault();e.stopPropagation();S.recommendationDismissed=S.recommendationDismissed||{};S.recommendationDismissed[i]="not_interested";sv();if(AUTH_USER)saveRecommendationFeedback(AUTH_USER.id,i).catch(error=>console.warn("[AniWatch] Recommendation feedback sync failed:",error));var item=t.closest(".recommendation-item");if(item)item.remove();if(!$("#recommendation-cards")?.children.length)$("#recommendation-cards").innerHTML='<p class="m">На сегодня подборка закончилась. Новые варианты появятся после обновления каталога.</p>';toast("Убрали тайтл из рекомендаций")}
 else if(a=="fav"){e.preventDefault();e.stopPropagation();var k=S.fav.indexOf(i),active=k<0;if(active)S.fav.push(i);else S.fav.splice(k,1);sv();document.querySelectorAll('[data-a="fav"][data-i="'+i+'"]').forEach(b=>{b.classList.toggle("active",active);b.classList.toggle("is-favorite",active);b.setAttribute("aria-pressed",String(active));b.setAttribute("aria-label",active?"Убрать из избранного":"Добавить в избранное");if(b.classList.contains("title-fav-btn"))b.innerHTML=active?"♥ В избранном":"♡ В избранное";else b.textContent=active?"♥":"♡"});toast(active?"Добавлено в избранное":"Убрано из избранного")}
 else if(a==="episode-range"){e.preventDefault();e.stopPropagation();applyEpisodeRange(Number(t.dataset.from),Number(t.dataset.to))}
 else if(a==="episode-jump-go"){e.preventDefault();e.stopPropagation();jumpToEpisode($("#episode-jump")?.value,i)}
 else if(a==="episode-last-watched"){e.preventDefault();e.stopPropagation();var historyEntry=S.hist&&S.hist[i],lastList=watchedFor(i),lastEpisode=Number(historyEntry&&historyEntry.ep)||(lastList.length?Math.max(...lastList):0);if(lastEpisode>0)jumpToEpisode(lastEpisode,i);else toast("Ты ещё не начинал смотреть это аниме")}
 else if(a==="episode-toggle"){e.preventDefault();e.stopPropagation();var watched=watchedFor(i),already=watched.includes(Number(v));setEpisodeWatched(i,v,!already);toast(!already?"Серия отмечена как просмотренная":"Отметка о просмотре снята")}
 else if(a==="inline-watch"){e.preventDefault();e.stopPropagation();var inlineAnime=M[i];if(inlineAnime)startInlineWatch(inlineAnime,Number(v)||1)}
 else if(a==="anime-media-open"){
  e.preventDefault();e.stopPropagation();
  var src=safeAnimeMediaUrl(t.dataset.src),title=t.dataset.title||"Просмотр";
  if(src){
   var overlay=document.createElement("div");overlay.className="anime-media-lightbox";overlay.setAttribute("role","dialog");overlay.setAttribute("aria-modal","true");overlay.setAttribute("aria-label",title);
   overlay.innerHTML='<div class="anime-media-lightbox-panel"><button type="button" class="anime-media-lightbox-close" aria-label="Закрыть">×</button>'+(t.dataset.kind==="video"?'<iframe src="'+esc(src)+'" title="'+esc(title)+'" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen></iframe>':'<img src="'+esc(src)+'" alt="'+esc(title)+'">')+'<span>'+esc(title)+'</span></div>';
   overlay.addEventListener("click",event=>{if(event.target===overlay||event.target.closest(".anime-media-lightbox-close"))closeDialog(overlay)});
   document.body.appendChild(overlay);
   openDialog(overlay);
  }
 }
 else if(a=="desc"){var p=$("#td"),open=t.getAttribute("aria-expanded")==="true";if(p){p.classList.toggle("collapsed",open);t.setAttribute("aria-expanded",String(!open));t.textContent=open?"Читать полностью":"Свернуть"}}
 else if(a=="rate"){S.rate[i]=+v;sv();draw()}
 else if(a=="random"){if(activePage()==="random")xrandom();else location.href=pageUrl("random")}
 else if(a=="g"){location.href=pageUrl("catalog",{g:v})}
 else if(a=="list-filter"){F.listStatus=v;V.mylist()}
 else if(a==="mylist-reload"){myListCloudAt=0;V.mylist()}
 else if(a==="collections-reload"){loadCollectionsView(routeArgs())}
  else if(a==="calendar-reload"){loadCalendar(true)}
  else if(a==="calendar-filter"){calendarFilter=v==="mine"?"mine":"all";renderCalendarCurrent()}
  else if(a==="calendar-day"){calendarSelectedDate=String(v||"");renderCalendarCurrent()}
  else if(a==="calendar-follow"){
   var shikiFollowId=String(v||""),followEnabled=!calendarFollows[shikiFollowId];
   (async()=>{
    try{
     if(AUTH_USER)await saveCalendarFollow(AUTH_USER.id,shikiFollowId,followEnabled);
     else{S.calendarFollows=S.calendarFollows||{};if(followEnabled)S.calendarFollows[shikiFollowId]={notifyBefore:true,notifyRelease:true};else delete S.calendarFollows[shikiFollowId];sv()}
     if(followEnabled)calendarFollows[shikiFollowId]={notifyBefore:true,notifyRelease:true};else delete calendarFollows[shikiFollowId];
     renderCalendarCurrent();
     toast(followEnabled?"Аниме добавлено в отслеживание":"Аниме убрано из отслеживания");
    }catch(error){console.error("[AniWatch] Calendar follow update failed:",error);toast(error.message||"Не удалось изменить отслеживание")}
   })()
  }
  else if(a==="calendar-push-toggle"){
   (async()=>{
    if(!AUTH_USER){openAuthModal();toast("Войди в аккаунт, чтобы включить push-уведомления");return}
    try{
     if(calendarPushState.enabled)await disableCalendarPush(AUTH_USER.id);
     else await enableCalendarPush(AUTH_USER.id);
     calendarPushState=await getCalendarPushState();
     renderCalendarCurrent();
     toast(calendarPushState.enabled?"Push-уведомления включены":"Push-уведомления отключены");
    }catch(error){console.warn("[AniWatch] Calendar push setup failed:",error);toast(error.message||"Не удалось настроить push-уведомления")}
   })()
  }
 else if(a==="add-to-collection"){
  if(!AUTH_USER){toast("Войди в аккаунт, чтобы создавать коллекции");return}
  listCollections(AUTH_USER.id).then(rows=>{
   var own=rows.filter(row=>row.owner_id===AUTH_USER.id),host=$("#collection-picker");
   if(!host){host=document.createElement("div");host.id="collection-picker";host.className="collection-picker";var actions=$(".title-actions");if(actions)actions.insertAdjacentElement("afterend",host)}
   if(!host)return;
   host.innerHTML=own.length?'<label>Добавить в мою коллекцию<select id="collection-picker-select">'+own.map(row=>'<option value="'+row.id+'">'+esc(row.title)+'</option>').join("")+'</select></label><button class="btn" type="button" data-a="collection-add-current">Добавить</button>':'<span>Сначала создай коллекцию.</span> <a href="collections.html">Открыть коллекции</a>';
  }).catch(error=>toast(error.message||"Не удалось загрузить коллекции"));
 }
 else if(a==="collection-add-current"){
  var targetId=$("#collection-picker-select")?.value,animeId=routeArgs()[0],anime=M[animeId];
  if(!targetId||!anime){toast("Не удалось определить коллекцию или аниме");return}
  addCollectionAnime(targetId,anime).then(()=>toast("Аниме добавлено в коллекцию")).catch(error=>toast(error.message||"Не удалось добавить аниме"));
 }
 else if(a==="collection-rate"){if(!AUTH_USER){toast("Войди в аккаунт, чтобы оценить коллекцию");return}var collectionId=new URLSearchParams(location.search).get("id");rateCollection(collectionId,AUTH_USER.id,+v).then(()=>loadCollectionsView([collectionId])).then(()=>toast("Оценка сохранена")).catch(error=>toast(error.message||"Не удалось сохранить оценку"))}
 else if(a==="collection-add-search-item"){
  if(!AUTH_USER){toast("Войди в аккаунт, чтобы управлять коллекциями");return}
  var selectedAnime=M[Number(t.dataset.id)],selectedCollection=routeArgs()[0];
  if(!selectedAnime||!selectedCollection){toast("Не удалось определить аниме или коллекцию");return}
  t.disabled=true;t.textContent="Добавляем…";
  addCollectionAnime(selectedCollection,selectedAnime).then(()=>{toast("Аниме добавлено в коллекцию");loadCollectionsView(routeArgs())}).catch(error=>{console.error("[AniWatch] Collection add failed:",error);toast(error.message||"Не удалось добавить аниме");t.disabled=false;t.textContent="Добавить"});
 }
 else if(a==="collection-remove-item"){removeCollectionAnime(t.dataset.id).then(()=>loadCollectionsView(routeArgs())).then(()=>toast("Аниме удалено из коллекции")).catch(error=>toast(error.message||"Не удалось удалить"))}
 else if(a==="collection-delete"){if(!confirm("Удалить коллекцию вместе со всеми её аниме и оценками?"))return;var collectionId=new URLSearchParams(location.search).get("id");deleteCollection(collectionId).then(()=>{toast("Коллекция удалена");location.href="collections.html"}).catch(error=>toast(error.message||"Не удалось удалить коллекцию"))}
 else if(a=="slide"&&H.length>1){featuredIndex=(featuredIndex+(+v)+H.length)%H.length;showFeatured()}
 else if(a=="slide-to"&&H.length>1){featuredIndex=(+v)%H.length;showFeatured()}
 else if(a=="pp"&&P){P.on=!P.on;tick(0);pauseSave();broadcastPlayback("playback")}
 else if(a=="sp"&&P){var s=[1,1.25,1.5,2];P.sp=s[(s.indexOf(P.sp)+1)%4];t.textContent=P.sp+"×";broadcastPlayback("playback")}
 else if(a=="seek"&&P){var r=t.getBoundingClientRect();P.t=Math.round((e.clientX-r.left)/r.width*DUR);tick(0);broadcastPlayback("playback")}
 else if(a=="room"){S.room=createRoomCode();S.roomHost=true;S.roomAnime=0;S.roomEpisode=0;sv();location.href=pageUrl("home")}
 else if(a==="room-invite-friends"){openRoomInvitePanel()}
  else if(a==="room-invite-close"){var invitePanel=$("#room-invite-panel");if(invitePanel)invitePanel.hidden=true}
  else if(a==="room-send-invite"){if(!AUTH_USER||!P||!S.room){toast("Комната недоступна");return}t.disabled=true;t.textContent="Отправляем…";sendWatchInvite(AUTH_USER.id,t.dataset.id,S.room,P.d.id,P.n).then(()=>{t.textContent="Отправлено";t.disabled=true;toast("Приглашение отправлено")}).catch(error=>{t.disabled=false;t.textContent="Пригласить";toast(error.message||"Не удалось отправить приглашение")})}
  else if(a==="friend-add"){if(!AUTH_USER){openAuthModal();return}t.disabled=true;sendFriendRequest(AUTH_USER.id,t.dataset.id).then(result=>{toast(result==="accepted"?"Вы теперь друзья":"Заявка отправлена");loadTogetherView()}).catch(error=>{t.disabled=false;toast(error.message||"Не удалось добавить друга")})}
  else if(a==="friend-accept"||a==="friend-decline"){if(!AUTH_USER)return;respondFriendRequest(t.dataset.id,AUTH_USER.id,a==="friend-accept").then(()=>{toast(a==="friend-accept"?"Теперь вы друзья":"Заявка отклонена");loadTogetherView()}).catch(error=>toast(error.message||"Не удалось обработать заявку"))}
  else if(a==="friend-remove"){if(!confirm("Удалить эту связь?"))return;removeFriend(t.dataset.id).then(()=>{toast("Готово");loadTogetherView()}).catch(error=>toast(error.message||"Не удалось удалить"))}
  else if(a==="invite-accept"){if(!AUTH_USER)return;respondWatchInvite(t.dataset.id,AUTH_USER.id,true).then(invite=>{S.room=invite.room_code;S.roomHost=false;S.roomAnime=Number(invite.anime_id);S.roomEpisode=Number(invite.episode)||1;sv();location.href=watchUrl(invite.anime_id,invite.episode)+"&room="+encodeURIComponent(invite.room_code)+"&guest=1"}).catch(error=>toast(error.message||"Приглашение уже недействительно"))}
  else if(a==="invite-decline"){if(!AUTH_USER)return;respondWatchInvite(t.dataset.id,AUTH_USER.id,false).then(()=>{toast("Приглашение отклонено");loadTogetherView()}).catch(error=>toast(error.message||"Не удалось отклонить приглашение"))}
  else if(a==="social-reload"){loadTogetherView()}
  else if(a=="room-copy"&&S.room){var invite=new URL(location.href);invite.searchParams.set("room",S.room);invite.searchParams.set("guest","1");var inviteText=invite.toString();if(navigator.clipboard&&navigator.clipboard.writeText)navigator.clipboard.writeText(inviteText).then(()=>toast("Ссылка-приглашение скопирована")).catch(()=>prompt("Скопируй ссылку на комнату:",inviteText));else prompt("Скопируй ссылку на комнату:",inviteText)}
 else if(a=="room-leave"){disconnectRoom();ROOM_CONNECTED=false;S.room="";S.roomHost=false;S.roomAnime=0;S.roomEpisode=0;sv();toast("Вы вышли из комнаты");location.href=watchUrl(P.d.id,P.n)}
 else if(a==="auth-mode"){var mode=v==="signup"?"signup":"login";document.querySelectorAll("[data-auth-mode]").forEach(b=>b.classList.toggle("on",b.dataset.authMode===mode));var modeInput=document.querySelector("#auth-form [name=auth-mode]");if(modeInput)modeInput.value=mode;var pass=$("#auth-password");if(pass)pass.autocomplete=mode==="signup"?"new-password":"current-password";var n=$("#auth-username-wrap");if(n)n.hidden=mode!=="signup";var ew=$("#auth-email-wrap");if(ew)ew.hidden=mode!=="signup";var emailInput=$("#auth-email");if(emailInput)emailInput.required=mode==="signup";var lw=$("#auth-login-wrap");if(lw)lw.hidden=mode==="signup";var loginInput=$("#auth-login");if(loginInput)loginInput.required=mode!=="signup";var submit=$("#auth-submit");if(submit)submit.textContent=mode==="signup"?"Создать аккаунт":"Войти";var status=$("#auth-message");if(status)status.textContent=""}
 else if(a==="profile-avatar"){var avatarInput=$("#profile-avatar-file");if(avatarInput)avatarInput.click()}else if(a==="profile-banner"){var bannerInput=$("#profile-banner-file");if(bannerInput)bannerInput.click()}else if(a==="profile-share"){var shareUrl=location.origin+location.pathname+"?user="+encodeURIComponent(AUTH_USER?.id||"");if(navigator.clipboard?.writeText){navigator.clipboard.writeText(shareUrl).then(()=>toast("Ссылка скопирована")).catch(()=>toast(shareUrl))}else toast(shareUrl)}else if(a==="auth-logout"){handleAuthLogout()}
 else if(a=="acc"){S.acc=v;sv();hd()}
 else if(a=="export"){exportBackup()}else if(a=="import"){var fileInput=$("#backup-file");if(fileInput)fileInput.click()}else if(a=="reset"){S={};df();sv();toast("Данные сброшены");draw()}else if(a=="reload"){location.reload()}});
listen(document,"submit",async e=>{e.preventDefault();var f=e.target.id;
 if(f=="site-search"){var sq=($("#q").value||"").trim();if(activePage()==="catalog"){F.q=sq;rc()}else location.href=pageUrl("catalog",{q:sq});return}
  if(f==="friend-search-form"){if(!AUTH_USER){openAuthModal();return}var query=($("#friend-search")?.value||"").trim(),host=$("#friend-search-results");if(!host)return;host.innerHTML='<p class="social-empty">Ищем пользователей…</p>';try{var found=await searchProfiles(query,AUTH_USER.id);host.innerHTML=found.length?found.map(person=>{var avatar=person.avatar_url&&/^https:\/\//i.test(person.avatar_url)?'<img src="'+esc(person.avatar_url)+'" alt="">':'<span>'+esc(String(person.username||"?").slice(0,1).toUpperCase())+'</span>';return '<article class="social-person"><div class="social-avatar">'+avatar+'</div><div class="social-person-info"><b><a href="profile.html?user='+encodeURIComponent(person.id)+'">'+esc(person.username||"Пользователь")+'</a></b><small>AniWatch</small></div><button class="btn" type="button" data-a="friend-add" data-id="'+esc(person.id)+'">Добавить</button></article>'}).join(""):'<p class="social-empty">Никого не нашли. Проверь написание ника.</p>'}catch(error){host.innerHTML='<p class="social-error">'+esc(error.message||"Ошибка поиска")+'</p>'}return;}
 if(f==="playback-settings-form"){var playbackData=new FormData(e.target);S.autoNextEpisode=playbackData.has("auto_next_episode");sv();toast("Настройки просмотра сохранены");V.profile();return}
 if(f==="library-import-form"){
  if(e.target.dataset.busy==="1")return;
  var importForm=e.target,importData=new FormData(importForm),importSource=String(importData.get("source")||""),importName=String(importData.get("username")||""),importUpdate=importData.has("update_existing");
  var importStatus=$("#library-import-status"),importButton=importForm.querySelector('button[type="submit"]');
  importForm.dataset.busy="1";if(importButton){importButton.disabled=true;importButton.textContent="Загружаем…"}
  if(importStatus)importStatus.textContent="Загружаем публичный список…";
  try{
   var imported=await fetchLibrary(importSource,importName);
   if(!imported.length)throw new Error("В публичном списке нет тайтлов.");
   imported.forEach(function(entry){
    var item=entry.source==="shikimori"?shikiToItem(entry.anime):(entry.media?mp(entry.media):null);
    if(item&&Number(item.id)){M[item.id]=item;S.shikiAnime=S.shikiAnime||{};S.shikiAnime[item.id]=item}
   });
   var merged=mergeImportedLibrary(S,imported,{updateExisting:importUpdate});
   S=merged.state;sv();
   if(AUTH_USER){
    var importProgress=imported.filter(entry=>Array.isArray(entry.watched)&&entry.watched.length).map(entry=>({animeId:entry.id,episodes:entry.watched}));
    if(importProgress.length)saveEpisodeProgressBatch(importProgress,AUTH_USER.id).catch(error=>console.warn("[AniWatch] Imported episode progress sync failed; marks stay local:",error));
   }
   var summary="Добавлено: "+merged.added+", обновлено: "+merged.updated+", пропущено: "+merged.skipped+". Отмечено серий: "+merged.watchedMarked+".";
   if(importStatus)importStatus.textContent="Импорт завершён. "+summary+" Статистика обновится после перезагрузки страницы.";
   toast("Библиотека импортирована: добавлено "+merged.added);
  }catch(error){
   console.warn("[AniWatch] Library import failed:",error);
   if(importStatus)importStatus.textContent=error.message||"Не удалось импортировать список.";
   toast(error.message||"Не удалось импортировать список");
  }finally{
   delete importForm.dataset.busy;
   if(importButton){importButton.disabled=false;importButton.textContent="Импортировать"}
  }
  return;
 }
 if(f==="profile-form"){var bio=String(new FormData(e.target).get("bio")||"").trim();if(bio.length>280){toast("Описание слишком длинное.");return}try{if(AUTH_USER)await saveProfileDetails({bio},AUTH_USER.id);S.bio=bio;sv();toast("Описание сохранено");V.profile()}catch(error){console.error("[AniWatch] Profile save failed:",error);toast(error.message||"Не удалось сохранить профиль")}return}
 if(f==="profile-privacy-form"){if(!AUTH_USER){toast("Войди в аккаунт, чтобы менять приватность.");return}var form=e.target,fd=new FormData(form);try{var saved=await saveProfilePrivacy({profile_visibility:fd.get("profile_visibility"),show_stats:fd.has("show_stats"),show_favorites:fd.has("show_favorites")},AUTH_USER.id);S.profileVisibility=saved.profile_visibility;S.showStats=saved.show_stats;S.showFavorites=saved.show_favorites;sv();toast("Настройки приватности сохранены");V.profile()}catch(error){console.error("[AniWatch] Privacy save failed:",error);toast(error.message||"Не удалось сохранить приватность")}return}
 if(f==="collection-create-form"||f==="collection-edit-form"){
  if(!AUTH_USER){toast("Войди в аккаунт, чтобы управлять коллекциями");return}
  var fd=new FormData(e.target),collectionId=new URLSearchParams(location.search).get("id");
  try{
   if(f==="collection-create-form"){var created=await createCollection(AUTH_USER.id,{title:fd.get("title"),description:fd.get("description"),cover_url:fd.get("cover_url"),is_public:fd.has("is_public")});toast("Коллекция создана");location.href="collections.html?id="+encodeURIComponent(created.id);}
   else if(f==="collection-edit-form"){await updateCollection(collectionId,{title:fd.get("title"),description:fd.get("description"),cover_url:fd.get("cover_url"),is_public:fd.has("is_public")});toast("Изменения сохранены");await loadCollectionsView([collectionId]);}
   else{var anime=M[Number(fd.get("anime_id"))];if(!anime)throw new Error("Сначала выбери аниме");await addCollectionAnime(collectionId,anime);toast("Аниме добавлено");await loadCollectionsView([collectionId]);}
  }catch(error){console.error("[AniWatch] Collection action failed:",error);toast(error.message||"Не удалось выполнить действие")}
  return;
 }
 if(f==="auth-form"){handleAuthSubmit(e.target);return}
 if(f=="cf"){var v=$("#ci").value.trim();if(!v)return;if(!ROOM_CONNECTED){toast("Нет соединения с комнатой");return}msg(S.name||"Вы",v);sendRoomEvent("chat",{name:S.name||"Гость",text:v.slice(0,500)}).catch(()=>toast("Не удалось отправить сообщение"));$("#ci").value=""}
 if(f==="jf"){var code=$("#jc").value.trim().toUpperCase().replace(/[^A-Z0-9]/g,"").slice(0,12);if(!code)return;var joinSettled=false,joinTimer=null;toast("Ищем ведущего комнаты…");connectRoom(code,{name:S.name||"Гость",host:false,onEvent:payload=>{if(joinSettled||payload.type!=="state"||!payload.host||!Number(payload.animeId))return;var animeId=Number(payload.animeId),episode=Math.max(1,Number(payload.episode)||1);joinSettled=true;if(joinTimer)clearTimeout(joinTimer);S.room=code;S.roomHost=false;S.roomAnime=animeId;S.roomEpisode=episode;sv();location.href=routeWatchUrl(animeId,episode)+"&room="+encodeURIComponent(code)+"&guest=1"}}).then(()=>{joinTimer=setTimeout(()=>{if(joinSettled)return;joinSettled=true;disconnectRoom();toast("Ведущий не ответил. Проверь код и попробуй снова.")},8000);return sendRoomEvent("request-state",{name:S.name||"Гость"})}).catch(error=>{if(joinSettled)return;joinSettled=true;if(joinTimer)clearTimeout(joinTimer);disconnectRoom();toast(error.message||"Не удалось подключиться к комнате")});return}});
listen(document,"input",e=>{if(e.target.id==="collection-anime-search"){clearTimeout(collectionSearchTimer);var value=e.target.value;collectionSearchTimer=setTimeout(()=>searchCollectionAnime(value),350)}});
listen(document,"input",e=>{var i=e.target.id;
 if(i==="episode-jump"){var value=e.target.value;if(value&&Number(value)>0&&$("#episode-range-list")){var from=Math.floor((Number(value)-1)/100)*100+1;applyEpisodeRange(from,from+99)}return}
 if(i=="q"&&activePage()==="catalog"){F.q=e.target.value.trim();rc()}
 if(i=="nm"){S.name=e.target.value.trim()||"Гость";sv();hd()}});
listen(document,"keydown",e=>{if(e.target.id==="episode-jump"&&e.key==="Enter"){e.preventDefault();jumpToEpisode(e.target.value,e.target.dataset.i||routeArgs()[0])}});
listen(document,"change",async e=>{if(e.target.id==="profile-avatar-file"){var file=e.target.files&&e.target.files[0];e.target.value="";if(!file)return;try{if(AUTH_USER){S.avatar=await uploadProfileAvatar(file,AUTH_USER.id)}else{if(!["image/jpeg","image/png","image/webp"].includes(file.type)||file.size>1024*1024)throw new Error("Выбери JPG, PNG или WebP до 1 МБ.");S.avatar=await new Promise((resolve,reject)=>{var reader=new FileReader();reader.onload=()=>resolve(String(reader.result));reader.onerror=reject;reader.readAsDataURL(file)})}sv();hd();toast("Фото профиля обновлено");V.profile()}catch(error){toast(error.message||"Не удалось загрузить фото")};return}if(e.target.id==="profile-banner-file"){var bannerFile=e.target.files&&e.target.files[0];e.target.value="";if(!bannerFile)return;try{if(AUTH_USER){S.banner=await uploadProfileBanner(bannerFile,AUTH_USER.id)}else{if(!["image/jpeg","image/png","image/webp"].includes(bannerFile.type)||bannerFile.size>1024*1024)throw new Error("Выбери JPG, PNG или WebP до 1 МБ.");S.banner=await new Promise((resolve,reject)=>{var reader=new FileReader();reader.onload=()=>resolve(String(reader.result));reader.onerror=reject;reader.readAsDataURL(bannerFile)})}sv();toast("Обложка профиля обновлена");V.profile()}catch(error){toast(error.message||"Не удалось загрузить обложку")}return}if(e.target.id==="backup-file"){var selected=e.target.files&&e.target.files[0];importBackup(selected);e.target.value="";return}if(e.target.id=="so"){F.s=e.target.value;rc()}if(e.target.id=="status-filter"){F.status=e.target.value;rc()}if(e.target.id=="anime-list-status"){var id=+e.target.dataset.id,value=e.target.value;if(value)S.watchlist[id]=value;else delete S.watchlist[id];sv();toast(value?"Статус сохранён":"Удалено из списка")}});
listen(window,"keydown",e=>{if(e.key==="Escape"){var authModal=document.getElementById("auth-modal");if(authModal){closeDialog(authModal);return}var lightbox=document.querySelector(".anime-media-lightbox");if(lightbox){closeDialog(lightbox);return}}if(/INPUT|SELECT|TEXTAREA/.test(e.target.tagName))return;var video=$("#stream-player video");if(!video)return;
 if(e.code==="Space"){e.preventDefault();if(video.paused)video.play().catch(()=>{});else video.pause()}else if(e.code==="ArrowRight"){video.currentTime=Math.min(video.duration||video.currentTime+10,video.currentTime+10)}else if(e.code==="ArrowLeft"){video.currentTime=Math.max(0,video.currentTime-10)}});
listen(document,"input",e=>{if(e.target.id!=="cs")return;xCF.q=e.target.value;F.q=xCF.q;var hq=$("#q");if(hq)hq.value=xCF.q;clearTimeout(xCF.h);xCF.h=setTimeout(()=>xcq(true),450)});
 listen(document,"change",e=>{var map={"cf-g":"g","cf-y":"y","cf-season":"season","cf-st":"st","cf-f":"f","cf-r":"minScore","cf-o":"o"};if(map[e.target.id]){xCF[map[e.target.id]]=e.target.value;xcq(true)}});
 listen(document,"click",e=>{if(e.target.closest("[data-xr]")){xcq(false);return}if(e.target.closest("[data-cf-reset]")){xCF.g="";xCF.y="";xCF.season="";xCF.st="";xCF.f="";xCF.o="POPULARITY_DESC";xCF.minScore="";xCF.q="";F.q="";F.g="";["cs","cf-g","cf-y","cf-season","cf-st","cf-f","cf-r","cf-o"].forEach(id=>{var el=$("#"+id);if(el)el.value=id==="cf-o"?"POPULARITY_DESC":""});var hq=$("#q");if(hq)hq.value="";xcq(true)}});
 addEventListener("pagehide",()=>{stashItems();disconnectRoom();if(socialChannelCleanup){socialChannelCleanup();socialChannelCleanup=null}});
idx();boot();
})();